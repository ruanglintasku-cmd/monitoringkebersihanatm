<?php
/**
 * routes/web.php — definisi rute lengkap.
 * @var App\Core\Router $router
 */

use App\Controllers\AuthController;
use App\Controllers\DashboardController;
use App\Controllers\AtmController;
use App\Controllers\ReportController;
use App\Controllers\SupervisorController;
use App\Controllers\PetugasController;
use App\Controllers\AdminController;
use App\Controllers\ScheduleController;
use App\Controllers\Api\MonitoringApiController;

// ---------- Auth ----------
$router->get('/',        [AuthController::class,'showLogin']);
$router->get('/login',   [AuthController::class,'showLogin']);
$router->post('/login',  [AuthController::class,'login']);
$router->get('/logout',  [AuthController::class,'logout']);
$router->get('/forgot',  [AuthController::class,'showForgot']);
$router->post('/forgot', [AuthController::class,'sendReset']);

// ---------- Dashboard ----------
$router->get('/dashboard',[DashboardController::class,'index'],['AuthMiddleware']);

// ---------- Admin: Master ATM ----------
$router->get('/admin/atm',          [AtmController::class,'index'],       ['AdminMiddleware']);
$router->post('/admin/atm/store',   [AtmController::class,'store'],       ['AdminMiddleware']);
$router->post('/admin/atm/update',  [AtmController::class,'update'],      ['AdminMiddleware']);
$router->post('/admin/atm/delete',  [AtmController::class,'delete'],      ['AdminMiddleware']);
$router->get('/admin/atm/export',   [AtmController::class,'exportExcel'], ['AdminMiddleware']);
$router->post('/admin/atm/import',  [AtmController::class,'importExcel'], ['AdminMiddleware']);

// ---------- Admin: User / Wilayah / Target / Log ----------
$router->get('/admin/users',          [AdminController::class,'users'],       ['AdminMiddleware']);
$router->post('/admin/users/store',   [AdminController::class,'storeUser'],   ['AdminMiddleware']);
$router->post('/admin/users/update',  [AdminController::class,'updateUser'],  ['AdminMiddleware']);
$router->post('/admin/users/toggle',  [AdminController::class,'toggleUser'],  ['AdminMiddleware']);
$router->get('/admin/regions',        [AdminController::class,'regions'],     ['AdminMiddleware']);
$router->post('/admin/regions/store', [AdminController::class,'storeRegion'], ['AdminMiddleware']);
$router->post('/admin/regions/delete',[AdminController::class,'deleteRegion'],['AdminMiddleware']);
$router->get('/admin/targets',        [AdminController::class,'targets'],     ['AdminMiddleware']);
$router->post('/admin/targets/store', [AdminController::class,'storeTarget'], ['AdminMiddleware']);
$router->get('/admin/logs',           [AdminController::class,'logs'],        ['AdminMiddleware']);

// ---------- Admin: Penjadwalan ----------
$router->get('/admin/schedule',        [ScheduleController::class,'index'],     ['AdminMiddleware']);
$router->post('/admin/schedule/store', [ScheduleController::class,'store'],     ['AdminMiddleware']);
$router->post('/admin/schedule/auto',  [ScheduleController::class,'autoRotate'],['AdminMiddleware']);
$router->post('/admin/schedule/delete',[ScheduleController::class,'delete'],    ['AdminMiddleware']);
$router->post('/admin/schedule/clear', [ScheduleController::class,'clearDate'], ['AdminMiddleware']);

// ---------- Supervisor ----------
$router->get('/supervisor/atm',     [SupervisorController::class,'atm'],     ['SupervisorMiddleware']);
$router->get('/supervisor/atm/export',[SupervisorController::class,'exportAtm'],['SupervisorMiddleware']);
$router->get('/supervisor/petugas', [SupervisorController::class,'petugas'], ['SupervisorMiddleware']);
$router->get('/supervisor/map',     [SupervisorController::class,'map'],     ['SupervisorMiddleware']);

// ---------- Petugas ----------
$router->get('/petugas/atm',          [PetugasController::class,'atm'],     ['PetugasMiddleware']);
$router->get('/petugas/history',      [PetugasController::class,'history'], ['PetugasMiddleware']);
$router->get('/petugas/report',       [ReportController::class,'create'],   ['PetugasMiddleware']);
$router->post('/petugas/report/store',[ReportController::class,'store'],    ['PetugasMiddleware']);

// ---------- Laporan & Export (semua role) ----------
$router->get('/reports',            [ReportController::class,'index'],      ['AuthMiddleware']);
$router->get('/reports/export/pdf', [ReportController::class,'exportPdf'],  ['AuthMiddleware']);
$router->get('/reports/export/xls', [ReportController::class,'exportExcel'],['AuthMiddleware']);

// ---------- API ----------
$router->get('/api/monitoring/summary',[MonitoringApiController::class,'summary'],['AuthMiddleware']);
$router->get('/api/monitoring/map',    [MonitoringApiController::class,'mapData'],['AuthMiddleware']);
$router->get('/api/monitoring/chart',  [MonitoringApiController::class,'chart'],  ['AuthMiddleware']);
$router->get('/api/monitoring/chart-area',[MonitoringApiController::class,'chartArea'],['AuthMiddleware']);
