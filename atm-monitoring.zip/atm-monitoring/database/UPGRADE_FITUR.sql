-- =====================================================================
-- UPGRADE_FITUR.sql — kolom & tabel untuk fitur baru
-- Aman dijalankan sekali. (Cek dulu kolom ada/tidak.)
-- phpMyAdmin -> database atm_monitoring -> tab SQL
-- =====================================================================
USE `atm_monitoring`;

-- 1) Kolom jarak GPS & flag lokasi mencurigakan pada laporan
DROP PROCEDURE IF EXISTS _addcol;
DELIMITER //
CREATE PROCEDURE _addcol(IN tname VARCHAR(64), IN cname VARCHAR(64), IN cdef VARCHAR(255))
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=tname AND COLUMN_NAME=cname) THEN
    SET @s=CONCAT('ALTER TABLE `',tname,'` ADD COLUMN `',cname,'` ',cdef);
    PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
  END IF;
END //
DELIMITER ;

CALL _addcol('cleaning_reports','gps_distance','DECIMAL(8,1) NULL COMMENT "jarak meter ke ATM"');
CALL _addcol('cleaning_reports','location_flag','VARCHAR(10) NULL COMMENT "ok|jauh|tanpa_gps"');
DROP PROCEDURE IF EXISTS _addcol;

-- 2) Tabel jadwal tugas (penjadwalan & rotasi)
CREATE TABLE IF NOT EXISTS `schedules` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `atm_id`      INT UNSIGNED NOT NULL,
  `user_id`     INT UNSIGNED NOT NULL,
  `schedule_date` DATE NOT NULL,
  `shift`       VARCHAR(20) NULL,
  `note`        VARCHAR(255) NULL,
  `created_by`  INT UNSIGNED NULL,
  `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sched` (`atm_id`,`schedule_date`),
  KEY `idx_sched_user` (`user_id`),
  KEY `idx_sched_date` (`schedule_date`),
  CONSTRAINT `fk_sched_atm` FOREIGN KEY (`atm_id`) REFERENCES `atm_locations`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sched_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SELECT 'Upgrade selesai' AS status;

-- 3) Tambah tipe foto 'temuan' (untuk foto temuan kerusakan, opsional)
ALTER TABLE `report_photos` MODIFY COLUMN `type` ENUM('before','after','temuan') NOT NULL;
SELECT 'Tipe foto temuan siap' AS status;
