-- =====================================================================
-- UPDATE_KOLOM_ATM.sql
-- Jalankan ini HANYA jika Anda sudah pernah import skema LAMA (tanpa kolom
-- pengelola/tipe_mesin dll) dan tidak ingin import ulang dari awal.
-- Script ini menambah kolom baru dengan aman (cek dulu apakah sudah ada).
-- Jika Anda import atm_monitoring.sql versi TERBARU, file ini TIDAK perlu.
-- =====================================================================
USE `atm_monitoring`;

DROP PROCEDURE IF EXISTS add_col_if_missing;
DELIMITER //
CREATE PROCEDURE add_col_if_missing(IN cname VARCHAR(64), IN cdef VARCHAR(255))
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='atm_locations' AND COLUMN_NAME=cname
  ) THEN
    SET @s = CONCAT('ALTER TABLE `atm_locations` ADD COLUMN `', cname, '` ', cdef);
    PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
  END IF;
END //
DELIMITER ;

CALL add_col_if_missing('pengelola','VARCHAR(100) NULL');
CALL add_col_if_missing('nama_pengelola','VARCHAR(100) NULL');
CALL add_col_if_missing('sewa_status','VARCHAR(20) NULL');
CALL add_col_if_missing('tipe_mesin','VARCHAR(30) NULL');
CALL add_col_if_missing('merk_mesin','VARCHAR(30) NULL');
CALL add_col_if_missing('jenis_lokasi','VARCHAR(60) NULL');
CALL add_col_if_missing('serial_number','VARCHAR(60) NULL');
CALL add_col_if_missing('service_hours','VARCHAR(60) NULL');
CALL add_col_if_missing('pks_status','VARCHAR(30) NULL');
CALL add_col_if_missing('kota_status','VARCHAR(30) NULL');
CALL add_col_if_missing('kontak_vendor','VARCHAR(40) NULL');
CALL add_col_if_missing('pic_slm','VARCHAR(100) NULL');

DROP PROCEDURE IF EXISTS add_col_if_missing;
SELECT 'Kolom tambahan siap. Sekarang jalankan import_atm_data.sql' AS status;
