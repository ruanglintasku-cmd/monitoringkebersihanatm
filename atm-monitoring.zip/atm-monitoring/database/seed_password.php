<?php
/**
 * seed_password.php
 * Mengisi password bcrypt asli untuk akun awal SETELAH import atm_monitoring.sql
 *
 * Jalankan SEKALI dari terminal:
 *   php database/seed_password.php
 *
 * Default password semua akun awal: password123  (ganti setelah login pertama)
 */

$host = '127.0.0.1';
$db   = 'atm_monitoring';
$user = 'root';
$pass = '';          // sesuaikan dengan MySQL Anda (XAMPP default kosong)
$port = 3306;

$DEFAULT_PASSWORD = 'password123';

$accounts = ['admin', 'supervisor', 'adi', 'siti'];

try {
    $pdo = new PDO(
        "mysql:host=$host;port=$port;dbname=$db;charset=utf8mb4",
        $user, $pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    fwrite(STDERR, "Koneksi gagal: " . $e->getMessage() . "\n");
    exit(1);
}

$hash = password_hash($DEFAULT_PASSWORD, PASSWORD_BCRYPT);
$stmt = $pdo->prepare("UPDATE users SET password = :h WHERE username = :u");

foreach ($accounts as $u) {
    $stmt->execute([':h' => $hash, ':u' => $u]);
    echo "OK  -> user '$u' password di-set ke '$DEFAULT_PASSWORD'\n";
}

echo "\nSelesai. Silakan login dengan salah satu akun di atas.\n";
echo "Disarankan ganti password setelah login pertama.\n";
