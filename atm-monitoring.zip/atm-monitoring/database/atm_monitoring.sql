-- =====================================================================
-- SISTEM MONITORING KEBERSIHAN ATM REGION IX KALIMANTAN
-- Database Schema  |  MySQL 5.7+ / MariaDB 10.4+  |  Engine: InnoDB
-- Charset: utf8mb4  |  Import via phpMyAdmin atau: mysql < atm_monitoring.sql
-- =====================================================================

SET FOREIGN_KEY_CHECKS = 0;
SET NAMES utf8mb4;
SET time_zone = '+08:00'; -- WITA

CREATE DATABASE IF NOT EXISTS `atm_monitoring`
  DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `atm_monitoring`;

-- ---------------------------------------------------------------------
-- 1. roles
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id`          TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`        VARCHAR(30)  NOT NULL,            -- admin | supervisor | petugas
  `label`       VARCHAR(60)  NOT NULL,
  `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_roles_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 2. regions  (Region IX dipecah ke area/wilayah)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `regions`;
CREATE TABLE `regions` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code`        VARCHAR(20)  NOT NULL,            -- RG09, AREA-BPN, dst
  `name`        VARCHAR(100) NOT NULL,
  `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_regions_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 3. cities  (kota dalam suatu region)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `cities`;
CREATE TABLE `cities` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `region_id`   INT UNSIGNED NOT NULL,
  `name`        VARCHAR(100) NOT NULL,
  `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cities_region` (`region_id`),
  CONSTRAINT `fk_cities_region` FOREIGN KEY (`region_id`)
      REFERENCES `regions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 4. users  (admin, supervisor, petugas dalam satu tabel + role_id)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_id`         TINYINT UNSIGNED NOT NULL,
  `region_id`       INT UNSIGNED NULL,            -- supervisor/petugas dibatasi region
  `nip`             VARCHAR(30)  NULL,            -- nomor induk pegawai
  `name`            VARCHAR(100) NOT NULL,
  `username`        VARCHAR(50)  NOT NULL,
  `email`           VARCHAR(120) NULL,
  `phone`           VARCHAR(20)  NULL,
  `password`        VARCHAR(255) NOT NULL,        -- password_hash() bcrypt
  `photo`           VARCHAR(255) NULL,
  `is_active`       TINYINT(1) NOT NULL DEFAULT 1,
  `remember_token`  VARCHAR(100) NULL,
  `reset_token`     VARCHAR(100) NULL,
  `reset_expires`   DATETIME NULL,
  `last_login_at`   DATETIME NULL,
  `created_by`      INT UNSIGNED NULL,
  `created_at`      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_username` (`username`),
  UNIQUE KEY `uq_users_email` (`email`),
  KEY `idx_users_role` (`role_id`),
  KEY `idx_users_region` (`region_id`),
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`)
      REFERENCES `roles` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_users_region` FOREIGN KEY (`region_id`)
      REFERENCES `regions` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 5. atm_locations  (master data ATM)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `atm_locations`;
CREATE TABLE `atm_locations` (
  `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code`            VARCHAR(30)  NOT NULL,        -- Kode ATM, contoh: BPN001
  `name`            VARCHAR(120) NOT NULL,
  `region_id`       INT UNSIGNED NOT NULL,
  `city_id`         INT UNSIGNED NULL,
  `area`            VARCHAR(100) NULL,
  `address`         TEXT NULL,
  `latitude`        DECIMAL(10,7) NULL,
  `longitude`       DECIMAL(10,7) NULL,
  `status`          ENUM('aktif','nonaktif','maintenance') NOT NULL DEFAULT 'aktif',
  `daily_target`    TINYINT UNSIGNED NOT NULL DEFAULT 1, -- target kebersihan / hari
  `assigned_to`     INT UNSIGNED NULL,           -- petugas penanggung jawab (users.id)
  `pengelola`       VARCHAR(100) NULL,
  `nama_pengelola`  VARCHAR(100) NULL,
  `sewa_status`     VARCHAR(20)  NULL,
  `tipe_mesin`      VARCHAR(30)  NULL,
  `merk_mesin`      VARCHAR(30)  NULL,
  `jenis_lokasi`    VARCHAR(60)  NULL,
  `serial_number`   VARCHAR(60)  NULL,
  `service_hours`   VARCHAR(60)  NULL,
  `pks_status`      VARCHAR(30)  NULL,
  `kota_status`     VARCHAR(30)  NULL,
  `kontak_vendor`   VARCHAR(40)  NULL,
  `pic_slm`         VARCHAR(100) NULL,
  `created_at`      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_atm_code` (`code`),
  KEY `idx_atm_region` (`region_id`),
  KEY `idx_atm_city` (`city_id`),
  KEY `idx_atm_assigned` (`assigned_to`),
  KEY `idx_atm_status` (`status`),
  CONSTRAINT `fk_atm_region` FOREIGN KEY (`region_id`)
      REFERENCES `regions` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_atm_city` FOREIGN KEY (`city_id`)
      REFERENCES `cities` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_atm_assigned` FOREIGN KEY (`assigned_to`)
      REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 6. targets  (target jumlah ATM yang harus dibersihkan per hari/region)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `targets`;
CREATE TABLE `targets` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `region_id`     INT UNSIGNED NULL,             -- NULL = target global
  `target_date`   DATE NOT NULL,
  `target_count`  SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  `created_by`    INT UNSIGNED NULL,
  `created_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_target_region_date` (`region_id`,`target_date`),
  KEY `idx_target_date` (`target_date`),
  CONSTRAINT `fk_target_region` FOREIGN KEY (`region_id`)
      REFERENCES `regions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 7. cleaning_reports  (laporan kebersihan per kunjungan)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `cleaning_reports`;
CREATE TABLE `cleaning_reports` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `atm_id`        INT UNSIGNED NOT NULL,
  `user_id`       INT UNSIGNED NOT NULL,         -- petugas pelapor
  `report_date`   DATE NOT NULL,
  `visit_time`    TIME NOT NULL,
  `status`        ENUM('bersih','kurang_bersih','kotor','tidak_bisa_dibersihkan')
                  NOT NULL DEFAULT 'bersih',
  `note`          TEXT NOT NULL,                 -- catatan wajib
  -- GPS saat pelaporan
  `gps_lat`       DECIMAL(10,7) NULL,
  `gps_lng`       DECIMAL(10,7) NULL,
  `gps_accuracy`  DECIMAL(8,2)  NULL,            -- meter
  `gps_timestamp` DATETIME NULL,
  `created_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_report_atm` (`atm_id`),
  KEY `idx_report_user` (`user_id`),
  KEY `idx_report_date` (`report_date`),
  KEY `idx_report_status` (`status`),
  CONSTRAINT `fk_report_atm` FOREIGN KEY (`atm_id`)
      REFERENCES `atm_locations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_report_user` FOREIGN KEY (`user_id`)
      REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 8. report_photos  (foto before/after, sudah ber-watermark)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `report_photos`;
CREATE TABLE `report_photos` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `report_id`     BIGINT UNSIGNED NOT NULL,
  `type`          ENUM('before','after','temuan') NOT NULL,
  `file_path`     VARCHAR(255) NOT NULL,         -- path file ber-watermark
  `file_size`     INT UNSIGNED NULL,
  `watermark_text` TEXT NULL,                    -- teks watermark yang ditempel
  `created_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_photo_report` (`report_id`),
  KEY `idx_photo_type` (`type`),
  CONSTRAINT `fk_photo_report` FOREIGN KEY (`report_id`)
      REFERENCES `cleaning_reports` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 9. notifications
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`       INT UNSIGNED NULL,             -- NULL = broadcast
  `title`         VARCHAR(150) NOT NULL,
  `message`       TEXT NOT NULL,
  `type`          ENUM('info','warning','danger','success') NOT NULL DEFAULT 'info',
  `is_read`       TINYINT(1) NOT NULL DEFAULT 0,
  `created_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_notif_user` (`user_id`),
  KEY `idx_notif_read` (`is_read`),
  CONSTRAINT `fk_notif_user` FOREIGN KEY (`user_id`)
      REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 10. activity_logs  (audit log)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `activity_logs`;
CREATE TABLE `activity_logs` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`       INT UNSIGNED NULL,
  `action`        VARCHAR(60)  NOT NULL,         -- login, logout, create_atm, dst
  `entity`        VARCHAR(60)  NULL,             -- nama tabel/entitas
  `entity_id`     VARCHAR(40)  NULL,
  `description`   VARCHAR(255) NULL,
  `ip_address`    VARCHAR(45)  NULL,
  `user_agent`    VARCHAR(255) NULL,
  `created_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_log_user` (`user_id`),
  KEY `idx_log_action` (`action`),
  KEY `idx_log_created` (`created_at`),
  CONSTRAINT `fk_log_user` FOREIGN KEY (`user_id`)
      REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================================
-- SEED DATA  (data awal supaya bisa langsung login & uji)
-- =====================================================================

INSERT INTO `roles` (`id`,`name`,`label`) VALUES
  (1,'admin','Administrator'),
  (2,'supervisor','Supervisor'),
  (3,'petugas','Petugas Kebersihan');

INSERT INTO `regions` (`id`,`code`,`name`) VALUES
  (1,'RG09','Region IX Kalimantan');

INSERT INTO `cities` (`id`,`region_id`,`name`) VALUES
  (1,1,'031 / BANJARMASIN'),
  (2,1,'146 / PONTIANAK'),
  (3,1,'148 / SAMARINDA'),
  (4,1,'149 / BALIKPAPAN'),
  (5,1,'159 / PALANGKARAYA');

-- Password untuk SEMUA akun awal = "password123"
-- PENTING: kolom password sengaja dikosongkan ('') di sini, lalu diisi
-- otomatis dengan hash bcrypt asli oleh skrip PHP setup (database/seed_password.php).
-- Jalankan skrip itu SEKALI setelah import SQL ini. (Lihat dokumentasi instalasi.)
INSERT INTO `users`
  (`id`,`role_id`,`region_id`,`nip`,`name`,`username`,`email`,`phone`,`password`,`is_active`) VALUES
  (1,1,1,'ADM001','Administrator','admin','admin@atm.local','08110000001','',1),
  (2,2,1,'SPV001','Budi Supervisor','supervisor','spv@atm.local','08110000002','',1),
  (3,3,1,'PTG001','Adi Kusmawan','adi','adi@atm.local','08110000003','',1),
  (4,3,1,'PTG002','Siti Rahma','siti','siti@atm.local','08110000004','',1);

INSERT INTO `atm_locations`
  (`code`,`name`,`region_id`,`city_id`,`area`,`address`,`latitude`,`longitude`,`status`,`daily_target`,`assigned_to`) VALUES
  ('BPN001','ATM Plaza Balikpapan',1,1,'Balikpapan Kota','Jl. Jend. Sudirman No.1, Balikpapan',-1.2654000,116.8312000,'aktif',1,3),
  ('BPN002','ATM Bandara SAMS',1,1,'Sepinggan','Bandara Sultan Aji M. Sulaiman, Balikpapan',-1.2683000,116.8945000,'aktif',1,3),
  ('SMD001','ATM Citra Niaga',1,2,'Samarinda Kota','Jl. Niaga Selatan, Samarinda',-0.5022000,117.1536000,'aktif',1,4),
  ('BJM001','ATM Duta Mall',1,3,'Banjarmasin Tengah','Jl. A. Yani Km 2, Banjarmasin',-3.3214000,114.6010000,'aktif',1,4);

INSERT INTO `targets` (`region_id`,`target_date`,`target_count`,`created_by`) VALUES
  (1, CURDATE(), 4, 1);

-- =====================================================================
-- VIEW BANTU: rekap status ATM hari ini (dipakai dashboard)
-- =====================================================================
DROP VIEW IF EXISTS `v_atm_today`;
CREATE VIEW `v_atm_today` AS
SELECT
  a.id            AS atm_id,
  a.code,
  a.name,
  a.region_id,
  a.latitude,
  a.longitude,
  a.assigned_to,
  CASE WHEN r.id IS NULL THEN 'belum' ELSE 'sudah' END AS today_status,
  r.status        AS clean_status,
  r.visit_time
FROM atm_locations a
LEFT JOIN cleaning_reports r
  ON r.atm_id = a.id AND r.report_date = CURDATE()
WHERE a.status = 'aktif';
