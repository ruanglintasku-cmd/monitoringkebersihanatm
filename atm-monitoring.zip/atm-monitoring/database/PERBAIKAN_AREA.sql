-- =====================================================================
-- PERBAIKAN_AREA.sql
-- Memperbaiki area yang tertukar + memakai format kode "031 / BANJARMASIN".
-- AMAN dijalankan kapan saja, tidak menghapus data ATM/laporan/user.
-- Jalankan di phpMyAdmin -> database atm_monitoring -> tab SQL.
-- =====================================================================
USE `atm_monitoring`;
SET FOREIGN_KEY_CHECKS = 0;

-- 1) Pastikan tabel cities punya 5 area dengan NAMA = format kode resmi.
--    Kita pakai nama unik sebagai kunci agar id tidak penting lagi.
--    Hapus baris cities lama yang tidak terpakai dulu (yang tidak punya ATM
--    akan di-relink di langkah 3, jadi aman menambahkan yang benar).

INSERT INTO `cities` (`region_id`,`name`)
SELECT 1, v.nm FROM (
  SELECT '031 / BANJARMASIN' AS nm UNION ALL
  SELECT '146 / PONTIANAK'        UNION ALL
  SELECT '148 / SAMARINDA'        UNION ALL
  SELECT '149 / BALIKPAPAN'       UNION ALL
  SELECT '159 / PALANGKARAYA'
) v
WHERE NOT EXISTS (SELECT 1 FROM `cities` c WHERE c.name = v.nm);

-- 2) Re-link setiap ATM ke city berdasarkan kolom `area` (sumber kebenaran).
--    Cocokkan berdasarkan teks area; toleran terhadap spasi.
UPDATE `atm_locations` a
JOIN `cities` c
  ON UPPER(REPLACE(c.name,' ','')) = UPPER(REPLACE(a.area,' ',''))
SET a.city_id = c.id
WHERE a.area IS NOT NULL AND a.area <> '';

-- 3) Untuk ATM yang area-nya hanya berisi nama kota tanpa kode (jika ada),
--    cocokkan dengan bagian nama setelah tanda '/'.
UPDATE `atm_locations` a
JOIN `cities` c
  ON UPPER(TRIM(SUBSTRING_INDEX(c.name,'/',-1))) = UPPER(TRIM(a.area))
SET a.city_id = c.id
WHERE (a.city_id IS NULL) AND a.area IS NOT NULL AND a.area <> '';

-- 4) Bersihkan baris cities lama yang tidak dipakai ATM mana pun
--    (mis. 'Balikpapan' polos hasil seed lama yang menyebabkan ketukaran).
DELETE c FROM `cities` c
WHERE NOT EXISTS (SELECT 1 FROM `atm_locations` a WHERE a.city_id = c.id)
  AND c.name NOT IN ('031 / BANJARMASIN','146 / PONTIANAK','148 / SAMARINDA','149 / BALIKPAPAN','159 / PALANGKARAYA');

SET FOREIGN_KEY_CHECKS = 1;

-- 5) Verifikasi hasil (jumlah ATM per area harus sesuai)
SELECT c.id, c.name AS area, COUNT(a.id) AS jumlah_atm
FROM `cities` c
LEFT JOIN `atm_locations` a ON a.city_id = c.id
GROUP BY c.id, c.name
ORDER BY c.name;
-- Hasil yang benar:
--   031 / BANJARMASIN  = 164
--   146 / PONTIANAK    = 133
--   148 / SAMARINDA    = 194
--   149 / BALIKPAPAN   = 186
--   159 / PALANGKARAYA = 95
