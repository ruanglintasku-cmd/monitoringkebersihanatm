<?php
/**
 * config/config.php — konfigurasi utama aplikasi
 *
 * BASE_URL terdeteksi OTOMATIS dari alamat yang diakses (localhost maupun domain
 * hosting), jadi Anda TIDAK perlu mengubah apa pun saat upload ke hosting.
 *
 * Yang biasanya HANYA perlu Anda ubah saat pindah ke hosting adalah bagian
 * DATABASE di bawah (host, nama db, user, password dari cPanel).
 */

/* =====================================================================
 * 1. DATABASE
 *    - Di XAMPP (lokal): biarкan seperti default.
 *    - Di hosting cPanel: ganti sesuai data dari menu "MySQL Databases".
 *      Biasanya DB_HOST tetap 'localhost', tapi DB_NAME/DB_USER memakai
 *      prefix akun cPanel, mis. 'namaakun_atmdb' dan 'namaakun_atmuser'.
 * ===================================================================== */
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'atm_monitoring');
define('DB_USER', 'root');
define('DB_PASS', '');

/* =====================================================================
 * 2. APLIKASI
 * ===================================================================== */
define('APP_NAME', 'Sistem Monitoring Kebersihan ATM Region IX Kalimantan');

/* ---- Deteksi otomatis http/https ---- */
$__https = (
    (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off') ||
    (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') ||
    (!empty($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443)
);
$__scheme = $__https ? 'https' : 'http';

/* ---- Deteksi host (domain atau localhost) ---- */
$__host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST']
        : (isset($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : 'localhost');

/* ---- Deteksi folder dasar otomatis (sampai sebelum /public) ----
 * SCRIPT_NAME contoh:
 *   /bankmandiri/atm-monitoring/public/index.php  -> base: /bankmandiri/atm-monitoring/public
 *   /public/index.php                              -> base: /public
 *   /index.php (jika public jadi document root)    -> base: ''
 */
$__script = isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '/index.php';
$__base = rtrim(str_replace('\\', '/', dirname($__script)), '/');
// Bila diakses lewat root project (index.php root me-redirect ke /public),
// pastikan base mengarah ke /public.
if ($__base === '' || substr($__base, -7) !== '/public') {
    // jika sedang di root project dan ada subfolder public, tambahkan
    if (is_dir(__DIR__ . '/../public') && substr($__base, -7) !== '/public') {
        // hanya tambahkan bila script benar-benar dari root (bukan dari dalam /public)
        if (basename(dirname($__script)) !== 'public') {
            $__base = ($__base === '' ? '' : $__base) . '/public';
        }
    }
}

define('BASE_URL', $__scheme . '://' . $__host . $__base);

/* ---- ENV otomatis: localhost = local, selain itu = production ---- */
$__isLocal = (strpos($__host, 'localhost') !== false || strpos($__host, '127.0.0.1') !== false || $__host === '::1');
define('APP_ENV', $__isLocal ? 'local' : 'production');

/* =====================================================================
 * 3. PATH (otomatis, jangan diubah)
 * ===================================================================== */
define('ROOT_PATH',    dirname(__DIR__));
define('APP_PATH',     ROOT_PATH . '/app');
define('VIEW_PATH',    APP_PATH . '/Views');
define('UPLOAD_PATH',  ROOT_PATH . '/public/uploads');
define('STORAGE_PATH', ROOT_PATH . '/storage');

/* =====================================================================
 * 4. KEAMANAN
 * ===================================================================== */
define('SESSION_NAME', 'ATM_MON_SESS');
define('SESSION_LIFETIME', 60 * 60 * 4); // 4 jam
define('CSRF_TOKEN_NAME', '_csrf');

/* ---- Zona waktu ---- */
date_default_timezone_set('Asia/Makassar'); // WITA
