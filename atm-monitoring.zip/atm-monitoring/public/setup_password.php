<?php
/**
 * setup_password.php — Pengisi password akun awal lewat BROWSER.
 *
 * CARA PAKAI:
 *  1. Letakkan file ini di dalam folder: public/  (sejajar dengan index.php)
 *  2. Buka di browser:
 *     http://localhost/bankmandiri/atm-monitoring/public/setup_password.php
 *  3. Setelah muncul "BERHASIL", HAPUS file ini demi keamanan.
 *
 * Password yang di-set untuk semua akun awal: password123
 */

// Ambil konfigurasi DB dari config aplikasi
require_once dirname(__DIR__) . '/config/config.php';

header('Content-Type: text/html; charset=utf-8');

$DEFAULT_PASSWORD = 'password123';
$accounts = array('admin', 'supervisor', 'adi', 'siti');

echo '<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8">';
echo '<title>Setup Password</title>';
echo '<style>body{font-family:Segoe UI,Arial,sans-serif;max-width:640px;margin:40px auto;color:#1c2430}'
   . '.ok{background:#e8f7ef;color:#13703f;border:1px solid #b8e6cd;padding:14px;border-radius:10px}'
   . '.err{background:#fdecea;color:#a32219;border:1px solid #f6c9c4;padding:14px;border-radius:10px}'
   . 'li{margin:4px 0}code{background:#f1f4f9;padding:2px 6px;border-radius:5px}'
   . '.warn{background:#fff6e5;color:#9a6700;border:1px solid #ffe2a8;padding:14px;border-radius:10px;margin-top:16px}</style>';
echo '</head><body><h2>Setup Password Akun Awal</h2>';

try {
    $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', DB_HOST, DB_PORT, DB_NAME);
    $pdo = new PDO($dsn, DB_USER, DB_PASS, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
} catch (PDOException $e) {
    echo '<div class="err"><b>Koneksi database GAGAL.</b><br>' . htmlspecialchars($e->getMessage())
       . '<br><br>Periksa <code>DB_USER</code> / <code>DB_PASS</code> di <code>config/config.php</code>.</div>';
    echo '</body></html>';
    exit;
}

$hash = password_hash($DEFAULT_PASSWORD, PASSWORD_BCRYPT);
$stmt = $pdo->prepare("UPDATE users SET password = :h WHERE username = :u");

echo '<div class="ok"><b>BERHASIL!</b> Password berikut sudah di-set ke <code>' . htmlspecialchars($DEFAULT_PASSWORD) . '</code>:</div><ul>';
$total = 0;
foreach ($accounts as $u) {
    $stmt->execute(array(':h' => $hash, ':u' => $u));
    $n = $stmt->rowCount();
    $total += $n;
    echo '<li><b>' . htmlspecialchars($u) . '</b> — ' . ($n > 0 ? 'OK' : 'tidak ditemukan / sudah sama') . '</li>';
}
echo '</ul>';

echo '<p>Total baris diperbarui: <b>' . $total . '</b>. Sekarang Anda bisa login.</p>';
echo '<div class="warn"><b>PENTING:</b> Demi keamanan, <b>HAPUS file <code>setup_password.php</code> ini</b> '
   . 'dari folder <code>public/</code> setelah berhasil login.</div>';
echo '<p style="margin-top:20px"><a href="login">→ Lanjut ke halaman Login</a></p>';
echo '</body></html>';
