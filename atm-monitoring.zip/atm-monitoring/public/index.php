<?php
/**
 * public/index.php — front controller (satu pintu masuk).
 */
require_once dirname(__DIR__) . '/app/Core/bootstrap.php';

use App\Core\Router;

$router = new Router();
require dirname(__DIR__) . '/routes/web.php';
$router->dispatch();
