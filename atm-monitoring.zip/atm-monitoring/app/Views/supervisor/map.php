<?php /** supervisor/map.php */ ?>
<div class="panel">
  <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:12px">
    <h3 style="margin:0">Peta Monitoring ATM</h3>
    <div style="display:flex;gap:16px;flex-wrap:wrap;font-size:13px;align-items:center">
      <span><i class="dot" style="background:#1aa260"></i> Sudah</span>
      <span><i class="dot" style="background:#e0392b"></i> Belum</span>
    </div>
  </div>

  <!-- Kontrol filter -->
  <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px">
    <div style="position:relative;flex:1;min-width:200px">
      <input id="searchId" type="text" autocomplete="off" placeholder="Cari ID / nama lokasi / alamat ATM…"
        style="width:100%;padding:9px 12px;border:1.5px solid var(--line);border-radius:9px">
      <div id="searchSug" class="ac-list"></div>
    </div>
    <select id="areaSel" style="padding:9px;border:1.5px solid var(--line);border-radius:9px;min-width:160px">
      <option value="">Semua Area</option>
    </select>
    <select id="statusSel" style="padding:9px;border:1.5px solid var(--line);border-radius:9px">
      <option value="">Semua Status</option>
      <option value="sudah">Sudah Dibersihkan</option>
      <option value="belum">Belum Dibersihkan</option>
    </select>
    <button id="resetBtn" class="btn btn-ghost" style="width:auto">Reset</button>
  </div>

  <div id="mapInfo" style="font-size:13px;color:var(--muted);margin-bottom:8px"></div>
  <div id="map" style="height:560px;border-radius:12px;overflow:hidden;border:1px solid var(--line)"></div>
</div>

<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<style>.dot{display:inline-block;width:11px;height:11px;border-radius:50%;margin-right:5px;vertical-align:middle}
.ac-list{position:absolute;left:0;right:0;top:100%;background:#fff;border:1px solid var(--line);border-radius:10px;box-shadow:0 8px 24px rgba(16,40,80,.12);max-height:280px;overflow-y:auto;z-index:1200;display:none;margin-top:4px}
.ac-item{padding:9px 12px;cursor:pointer;font-size:13.5px;border-bottom:1px solid #f0f3f8}
.ac-item:hover{background:var(--blue-100)}
.ac-item b{color:var(--blue-800)}
.leaflet-pop b{font-size:13px}</style>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
(function(){
  var map = L.map('map').setView([-1.2, 116.8], 6);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap',maxZoom:19}).addTo(map);

  var ALL = [];               // semua marker data
  var layer = L.layerGroup().addTo(map);
  var markersById = {};       // code -> entry
  var markerList = [];        // daftar entry untuk pencarian

  function color(s){ return s==='sudah' ? '#1aa260' : '#e0392b'; }
  function icon(c, big){
    var s = big?26:16;
    return L.divIcon({className:'',html:'<div style="background:'+c+';width:'+s+'px;height:'+s+'px;border-radius:50%;border:3px solid #fff;box-shadow:0 1px 5px rgba(0,0,0,.5)"></div>',iconSize:[s,s]});
  }
  function popHtml(m){
    var photo = m.last_photo ? '<img src="'+m.last_photo+'" style="width:180px;border-radius:6px;margin-top:6px">' : '';
    return '<div class="leaflet-pop"><b>'+m.code+' — '+m.name+'</b><br>'+
      '<small>'+(m.address||'')+'</small><br>'+
      'Area: '+(m.city_name||'-')+'<br>'+
      'Petugas: '+(m.petugas_name||'-')+'<br>'+
      'Status: <b style="color:'+color(m.today_status)+'">'+(m.today_status==='sudah'?'Sudah Dibersihkan':'Belum Dibersihkan')+'</b>'+
      photo+'</div>';
  }

  function render(){
    layer.clearLayers(); markersById = {};
    var area = document.getElementById('areaSel').value;
    var status = document.getElementById('statusSel').value;
    var bounds = [];
    markerList = [];
    ALL.forEach(function(m){
      if(!m.latitude||!m.longitude) return;
      if(area && String(m.city_id)!==String(area)) return;
      if(status && m.today_status!==status) return;
      var lat=parseFloat(m.latitude), lng=parseFloat(m.longitude);
      var mk = L.marker([lat,lng],{icon:icon(color(m.today_status),false)}).bindPopup(popHtml(m));
      mk.addTo(layer);
      var entry = {marker:mk, latlng:[lat,lng],
        code:(m.code||''), name:(m.name||''), address:(m.address||''),
        hay:((m.code||'')+' '+(m.name||'')+' '+(m.address||'')).toUpperCase()};
      markersById[(m.code||'').toUpperCase()] = entry;
      markerList.push(entry);
      bounds.push([lat,lng]);
    });
    var info = document.getElementById('mapInfo');
    info.textContent = 'Menampilkan ' + bounds.length + ' titik ATM' + (area?' di area terpilih':'') + (status?(' ('+status+')'):'') + '.';
    if(bounds.length){ map.fitBounds(bounds,{padding:[50,50], maxZoom:13}); }
  }

  function focusEntry(entry){
    map.setView(entry.latlng, 17, {animate:true});
    entry.marker.openPopup();
    var hl = L.circleMarker(entry.latlng,{radius:26,color:'#0061c2',weight:4,fill:false}).addTo(map);
    setTimeout(function(){ map.removeLayer(hl); }, 2500);
  }

  function searchById(){
    var q = (document.getElementById('searchId').value||'').trim().toUpperCase();
    if(!q) return;
    // cocokkan terhadap kode, nama, atau alamat
    var found=null;
    for(var i=0;i<markerList.length;i++){
      if(markerList[i].hay.indexOf(q)>=0){ found=markerList[i]; break; }
    }
    if(found){ focusEntry(found); document.getElementById('searchSug').style.display='none'; }
    else { alert('ATM "'+q+'" tidak ditemukan pada filter saat ini. Coba Reset filter dulu.'); }
  }

  function showSuggestions(){
    var q=(document.getElementById('searchId').value||'').trim().toUpperCase();
    var box=document.getElementById('searchSug');
    if(q.length<2){ box.style.display='none'; return; }
    var matches=markerList.filter(function(e){ return e.hay.indexOf(q)>=0; }).slice(0,12);
    if(!matches.length){ box.style.display='none'; return; }
    box.innerHTML='';
    matches.forEach(function(e){
      var d=document.createElement('div'); d.className='ac-item';
      d.innerHTML='<b>'+e.code+'</b> — '+e.name+'<br><small style="color:#647082">'+(e.address||'')+'</small>';
      d.onclick=function(){ document.getElementById('searchId').value=e.code+' — '+e.name; box.style.display='none'; focusEntry(e); };
      box.appendChild(d);
    });
    box.style.display='block';
  }

  document.getElementById('areaSel').addEventListener('change', render);
  document.getElementById('statusSel').addEventListener('change', render);
  document.getElementById('searchId').addEventListener('keydown', function(e){ if(e.key==='Enter'){ e.preventDefault(); searchById(); }});
  document.getElementById('searchId').addEventListener('input', showSuggestions);
  document.addEventListener('click', function(e){
    var box=document.getElementById('searchSug');
    if(box && e.target!==document.getElementById('searchId') && !box.contains(e.target)) box.style.display='none';
  });
  document.getElementById('resetBtn').addEventListener('click', function(){
    document.getElementById('areaSel').value='';
    document.getElementById('statusSel').value='';
    document.getElementById('searchId').value='';
    render();
  });

  fetch('<?= url('api/monitoring/map') ?>')
    .then(function(r){return r.json();})
    .then(function(d){
      ALL = d.markers||[];
      // isi dropdown area
      var sel = document.getElementById('areaSel');
      (d.cities||[]).forEach(function(c){
        var o=document.createElement('option'); o.value=c.id; o.textContent=c.name; sel.appendChild(o);
      });
      render();
    })
    .catch(function(){ document.getElementById('mapInfo').textContent='Gagal memuat data peta.'; });
})();
</script>
