<?php /** supervisor/petugas_monitor.php */ ?>
<div class="panel">
  <h3>Monitoring Kinerja Petugas</h3>
  <div style="overflow-x:auto">
  <table class="tbl">
    <thead><tr><th>Nama Petugas</th><th>Total ATM</th><th>Selesai Hari Ini</th><th>Belum</th><th>Kinerja</th><th>Aktivitas Terakhir</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r):
      $total=(int)$r['total_atm']; $done=(int)$r['done_today']; $belum=max(0,$total-$done);
      $pct=$total?round($done/$total*100):0; ?>
      <tr>
        <td><b><?= e($r['name']) ?></b></td>
        <td><?= $total ?></td>
        <td style="color:var(--ok);font-weight:600"><?= $done ?></td>
        <td style="color:var(--danger);font-weight:600"><?= $belum ?></td>
        <td style="min-width:160px">
          <div class="progress" style="margin:0"><span style="width:<?= min(100,$pct) ?>%"></span></div>
          <small style="color:var(--muted)"><?= $pct ?>%</small>
        </td>
        <td><?= $r['last_active']?e(tgl_id($r['last_active'],true)):'Belum ada' ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if(!$rows): ?><tr><td colspan="6" style="text-align:center;color:var(--muted);padding:24px">Tidak ada petugas.</td></tr><?php endif; ?>
    </tbody>
  </table>
  </div>
</div>
<style>.tbl{width:100%;border-collapse:collapse;font-size:13.5px}.tbl th{text-align:left;background:#f4f7fb;color:#46546a;padding:10px;border-bottom:2px solid var(--line);font-size:12px;text-transform:uppercase}.tbl td{padding:10px;border-bottom:1px solid #eef2f7;vertical-align:middle}</style>
