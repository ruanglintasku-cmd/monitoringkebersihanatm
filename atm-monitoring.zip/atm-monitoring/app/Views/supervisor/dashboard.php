<?php /** supervisor/dashboard.php */ $s=$stats; ?>
<div class="cards">
  <div class="card accent"><div class="k">Total ATM (Region)</div><div class="v"><?= $s['totalAtm'] ?></div></div>
  <div class="card"><div class="k">Sudah Dibersihkan</div><div class="v" style="color:var(--ok)"><?= $s['sudah'] ?></div></div>
  <div class="card"><div class="k">Belum Dibersihkan</div><div class="v" style="color:var(--danger)"><?= $s['belum'] ?></div></div>
  <div class="card"><div class="k">Petugas Aktif</div><div class="v"><?= $s['petugasAktif'] ?></div></div>
</div>
<div class="panel">
  <h3>Progress Hari Ini — <?= $s['persen'] ?>%</h3>
  <div class="progress"><span style="width:<?= min(100,$s['persen']) ?>%"></span></div>
</div>
<div class="panel"><h3>Monitoring Petugas & Peta</h3>
  <div class="placeholder">Tabel kinerja petugas dan peta lokasi real-time (tahap berikutnya).</div>
</div>
