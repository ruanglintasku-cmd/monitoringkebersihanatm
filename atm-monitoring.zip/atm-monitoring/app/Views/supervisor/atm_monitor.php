<?php /** supervisor/atm_monitor.php */
function tdot($s){ $c=$s==='sudah'?'#1aa260':'#e0392b'; return '<span style="display:inline-block;width:9px;height:9px;border-radius:50%;background:'.$c.';margin-right:6px"></span>'; }
?>
<div class="cards" style="margin-bottom:18px">
  <div class="card accent"><div class="k">Total ATM (filter)</div><div class="v"><?= (int)$total ?></div></div>
  <div class="card"><div class="k">Sudah Dibersihkan</div><div class="v" style="color:var(--ok)"><?= (int)$sudah ?></div></div>
  <div class="card"><div class="k">Belum Dibersihkan</div><div class="v" style="color:var(--danger)"><?= (int)$belum ?></div></div>
</div>

<div class="panel">
  <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:14px">
    <h3 style="margin:0">Monitoring ATM Hari Ini</h3>
    <a class="btn btn-ghost" style="width:auto" href="<?= url('supervisor/atm/export?q='.urlencode($q).'&city_id='.(int)$cityId.'&status='.urlencode($status)) ?>">Export Excel</a>
  </div>

  <form method="get" action="<?= url('supervisor/atm') ?>" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px">
    <input type="text" name="q" value="<?= e($q) ?>" placeholder="Cari kode / nama / alamat ATM…"
      style="flex:1;min-width:200px;padding:9px 12px;border:1.5px solid var(--line);border-radius:9px">
    <select name="city_id" style="padding:9px;border:1.5px solid var(--line);border-radius:9px">
      <option value="">Semua Area</option>
      <?php foreach ($cities as $c): ?>
        <option value="<?= $c['id'] ?>" <?= $cityId==$c['id']?'selected':'' ?>><?= e($c['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select name="status" style="padding:9px;border:1.5px solid var(--line);border-radius:9px">
      <option value="">Semua Status</option>
      <option value="sudah" <?= $status==='sudah'?'selected':'' ?>>Sudah Dibersihkan</option>
      <option value="belum" <?= $status==='belum'?'selected':'' ?>>Belum Dibersihkan</option>
    </select>
    <button class="btn btn-primary" style="width:auto">Cari</button>
    <?php if($q!==''||$cityId||$status!==''): ?>
      <a class="btn btn-ghost" style="width:auto" href="<?= url('supervisor/atm') ?>">Reset</a>
    <?php endif; ?>
  </form>

  <div style="overflow-x:auto">
  <table class="tbl">
    <thead><tr><th>Kode</th><th>Nama</th><th>Area</th><th>Petugas</th><th>Status Hari Ini</th><th>Kebersihan</th><th>Jam</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><b><?= e($r['code']) ?></b></td>
        <td><?= e($r['name']) ?></td>
        <td><?= e(isset($r['city_name'])?$r['city_name']:'-') ?></td>
        <td><?= e(isset($r['petugas_name'])?$r['petugas_name']:'-') ?></td>
        <td><?= tdot($r['today_status']) ?><?= $r['today_status']==='sudah'?'Sudah Dibersihkan':'Belum Dibersihkan' ?></td>
        <td><?= e($r['clean_status']?ucwords(str_replace('_',' ',$r['clean_status'])):'-') ?></td>
        <td><?= $r['visit_time']?e(substr($r['visit_time'],0,5)).' WITA':'-' ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if(!$rows): ?><tr><td colspan="7" style="text-align:center;color:var(--muted);padding:24px">Tidak ada ATM sesuai filter.</td></tr><?php endif; ?>
    </tbody>
  </table>
  </div>
  <p style="margin-top:10px;color:var(--muted);font-size:13px">Menampilkan <?= count($rows) ?> ATM.</p>
</div>
<style>.tbl{width:100%;border-collapse:collapse;font-size:13.5px}.tbl th{text-align:left;background:#f4f7fb;color:#46546a;padding:10px;border-bottom:2px solid var(--line);font-size:12px;text-transform:uppercase}.tbl td{padding:10px;border-bottom:1px solid #eef2f7}.tbl tr:hover td{background:#fafcff}</style>
