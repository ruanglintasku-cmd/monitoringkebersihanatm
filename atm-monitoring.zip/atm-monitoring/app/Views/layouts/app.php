<?php
/** app/Views/layouts/app.php — layout dashboard.
 *  Variabel: $title, $content (HTML string), $active (key menu), $notifCount */
$u = auth();
$role = isset($u['role'])?$u['role']:'';
$active = isset($active)?$active:'';
$notifCount = isset($notifCount)?$notifCount:0;

// Menu per role
$menus = [
  'admin' => [
    ['group','Utama'],
    ['dashboard','Dashboard','dashboard'],
    ['group','Master Data'],
    ['admin/atm','Data ATM','atm'],
    ['admin/users','Kelola User','users'],
    ['admin/regions','Area','regions'],
    ['admin/targets','Target Harian','targets'],
    ['admin/schedule','Penjadwalan','schedule'],
    ['group','Operasional'],
    ['reports','Laporan','reports'],
    ['admin/logs','Audit Log','logs'],
  ],
  'supervisor' => [
    ['group','Utama'],
    ['dashboard','Dashboard','dashboard'],
    ['group','Monitoring'],
    ['supervisor/atm','Monitoring ATM','atm'],
    ['supervisor/petugas','Monitoring Petugas','petugas'],
    ['supervisor/map','Peta Monitoring','map'],
    ['reports','Laporan','reports'],
  ],
  'petugas' => [
    ['group','Utama'],
    ['dashboard','Dashboard','dashboard'],
    ['group','Tugas Saya'],
    ['petugas/atm','ATM Tanggung Jawab','atm'],
    ['petugas/report','Buat Laporan','report'],
    ['petugas/history','Histori Pekerjaan','history'],
  ],
];
$menu = isset($menus[$role])?$menus[$role]:array();
$initials = strtoupper(mb_substr(isset($u['name'])?$u['name']:'U', 0, 1));
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e(isset($title)?$title:'Dashboard') ?> — Monitoring ATM Region IX</title>
<link rel="stylesheet" href="<?= asset('css/app.css') ?>">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@2.47.0/tabler-icons.min.css">
</head>
<body>
<div class="app">
  <aside class="sidebar" id="sidebar">
    <div class="brand">
      <div class="logo">A</div>
      <b>Monitoring ATM<br>Region IX</b>
    </div>
    <nav class="nav">
      <?php foreach ($menu as $item): ?>
        <?php if ($item[0] === 'group'): ?>
          <div class="group"><?= e($item[1]) ?></div>
        <?php else: $path=$item[0]; $label=$item[1]; $key=$item[2]; ?>
          <a href="<?= url($path) ?>" class="<?= $active===$key?'active':'' ?>"><?= e($label) ?></a>
        <?php endif; ?>
      <?php endforeach; ?>
      <div class="group">Akun</div>
      <a href="<?= url('logout') ?>">Keluar</a>
    </nav>
  </aside>

  <div class="main">
    <header class="topbar">
      <div style="display:flex;align-items:center;gap:12px">
        <button class="menu-btn" onclick="document.getElementById('sidebar').classList.toggle('open')">☰</button>
        <h1><?= e(isset($title)?$title:'Dashboard') ?></h1>
      </div>
      <div class="right">
        <?php if ($notifCount > 0): ?>
          <div class="badge-notif">Belum dibersihkan: <b><?= (int)$notifCount ?></b></div>
        <?php endif; ?>
        <div class="userchip">
          <div class="avatar"><?= e($initials) ?></div>
          <div>
            <div><?= e(isset($u['name'])?$u['name']:'') ?></div>
            <div class="role"><?= e($role) ?></div>
          </div>
        </div>
      </div>
    </header>
    <main class="content">
      <?= $content ?>
    </main>
  </div>
</div>
</body>
</html>
