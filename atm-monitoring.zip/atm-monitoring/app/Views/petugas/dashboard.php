<?php /** petugas/dashboard.php */ $s=$stats; ?>
<div class="cards">
  <div class="card accent"><div class="k">ATM Tanggung Jawab</div><div class="v"><?= $s['totalAtm'] ?></div></div>
  <div class="card"><div class="k">Sudah Dilaporkan</div><div class="v" style="color:var(--ok)"><?= $s['sudah'] ?></div></div>
  <div class="card"><div class="k">Belum Dilaporkan</div><div class="v" style="color:var(--danger)"><?= $s['belum'] ?></div></div>
</div>
<div class="panel">
  <h3>Progress Tugas Hari Ini — <?= $s['persen'] ?>%</h3>
  <div class="progress"><span style="width:<?= min(100,$s['persen']) ?>%"></span></div>
  <p style="margin-top:12px"><a class="btn btn-primary" style="width:auto;display:inline-flex" href="<?= url('petugas/report') ?>">+ Buat Laporan Kebersihan</a></p>
</div>
<div class="panel"><h3>Histori Pekerjaan</h3>
  <div class="placeholder">Daftar ATM, upload foto before/after + kamera + GPS + watermark (tahap berikutnya).</div>
</div>
