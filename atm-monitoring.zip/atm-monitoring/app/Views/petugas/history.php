<?php /** petugas/history.php */ ?>
<div class="panel">
  <h3>Histori Pekerjaan Saya</h3>
  <div style="overflow-x:auto">
  <table class="tbl">
    <thead><tr><th>Tanggal</th><th>Jam</th><th>ATM</th><th>Status</th><th>Catatan</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><?= e(tgl_id($r['report_date'])) ?></td>
        <td><?= e(substr($r['visit_time'],0,5)) ?> WITA</td>
        <td><b><?= e($r['atm_code']) ?></b> — <?= e($r['atm_name']) ?></td>
        <td><?= e(ucwords(str_replace('_',' ',$r['status']))) ?></td>
        <td style="max-width:280px;font-size:13px"><?= e($r['note']) ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if(!$rows): ?><tr><td colspan="5" style="text-align:center;color:var(--muted);padding:24px">Belum ada histori.</td></tr><?php endif; ?>
    </tbody>
  </table>
  </div>
</div>
<style>.tbl{width:100%;border-collapse:collapse;font-size:13.5px}.tbl th{text-align:left;background:#f4f7fb;color:#46546a;padding:10px;border-bottom:2px solid var(--line);font-size:12px;text-transform:uppercase}.tbl td{padding:10px;border-bottom:1px solid #eef2f7}</style>
