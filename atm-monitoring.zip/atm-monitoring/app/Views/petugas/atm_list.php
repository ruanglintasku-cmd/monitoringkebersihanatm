<?php /** petugas/atm_list.php */ ?>
<?php if(!empty($fromSchedule)): ?>
  <div class="alert alert-ok" style="margin-bottom:14px">📅 Menampilkan <b>jadwal tugas Anda hari ini</b> (<?= e(tgl_id($today)) ?>).</div>
<?php endif; ?>
<div class="panel">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
    <h3 style="margin:0">ATM Tugas Saya</h3>
    <a class="btn btn-primary" style="width:auto" href="<?= url('petugas/report') ?>">+ Buat Laporan</a>
  </div>
  <div class="grid">
  <?php foreach ($atms as $a): ?>
    <div class="atm-card">
      <div style="display:flex;justify-content:space-between;align-items:start">
        <div><b><?= e($a['code']) ?></b><div style="font-size:13px;color:var(--muted)"><?= e($a['name']) ?></div></div>
        <?php if($a['reported']): ?>
          <span class="tag ok">Sudah dilaporkan</span>
        <?php else: ?>
          <span class="tag no">Belum</span>
        <?php endif; ?>
      </div>
      <div style="font-size:12.5px;color:var(--muted);margin-top:8px"><?= e($a['address']) ?></div>
      <?php if(!empty($a['latitude'])): ?>
        <a href="https://www.google.com/maps?q=<?= e($a['latitude']) ?>,<?= e($a['longitude']) ?>" target="_blank"
           style="display:inline-block;margin-top:10px;font-size:12.5px;font-weight:600;color:var(--blue-700)">📍 Buka Rute (Google Maps)</a>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
  <?php if(!$atms): ?><div class="placeholder">Belum ada ATM/tugas untuk Anda hari ini.</div><?php endif; ?>
  </div>
</div>
<style>
  .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:14px}
  .atm-card{border:1px solid var(--line);border-radius:12px;padding:14px}
  .tag{font-size:11px;font-weight:600;padding:3px 9px;border-radius:99px}
  .tag.ok{background:#e8f7ef;color:#13703f}.tag.no{background:#fdecea;color:#a32219}
</style>
