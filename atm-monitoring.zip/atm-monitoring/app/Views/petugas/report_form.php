<?php /** petugas/report_form.php — searchable ATM + kamera-only + temuan + jarak GPS */ ?>
<?php if (!empty($error)): ?><div class="alert alert-error" style="margin-bottom:16px"><?= e($error) ?></div><?php endif; ?>

<div class="panel">
  <h3>Form Laporan Kebersihan ATM</h3>
  <p style="color:var(--muted);font-size:13px;margin-bottom:16px">
    Ketik ID/kode ATM untuk mencari. Foto wajib diambil LANGSUNG dari kamera (galeri & file diblokir). GPS, watermark, dan timestamp otomatis.
  </p>

  <form id="reportForm" method="post" action="<?= url('petugas/report/store') ?>" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <input type="hidden" name="gps_lat" id="gps_lat">
    <input type="hidden" name="gps_lng" id="gps_lng">
    <input type="hidden" name="gps_accuracy" id="gps_accuracy">
    <input type="hidden" name="atm_id" id="atm_id">

    <div class="form-grid">
      <!-- SEARCHABLE ATM -->
      <div class="field">
        <label>Cari ATM (ketik ID / kode, mis. s1rhj)</label>
        <div class="control" style="position:relative">
          <input type="text" id="atmSearch" autocomplete="off" placeholder="Ketik ID ATM atau nama lokasi…"
            style="width:100%;padding:11px;border:1.5px solid var(--line);border-radius:10px">
          <div id="atmResults" class="ac-list"></div>
        </div>
        <div id="atmChosen" style="margin-top:8px;font-size:13px"></div>
      </div>
      <div class="field">
        <label>Status Kebersihan</label>
        <div class="control">
          <select name="status" required style="width:100%;padding:11px;border:1.5px solid var(--line);border-radius:10px">
            <option value="bersih">Bersih</option>
            <option value="kurang_bersih">Kurang Bersih</option>
            <option value="kotor">Kotor</option>
            <option value="tidak_bisa_dibersihkan">Tidak Bisa Dibersihkan</option>
          </select>
        </div>
      </div>
    </div>

    <div class="field">
      <label>Catatan Petugas (wajib)</label>
      <textarea name="note" required rows="3" placeholder="cth: ATM bersih, area sekitar rapi / ATM terkunci / mesin rusak"
        style="width:100%;padding:11px;border:1.5px solid var(--line);border-radius:10px;font-family:inherit"></textarea>
    </div>

    <div class="gps-status" id="gpsStatus">📍 Mendeteksi lokasi GPS…</div>
    <div class="gps-dist" id="gpsDist" style="display:none"></div>

    <!-- FOTO: kamera live -->
    <div class="photo-grid">
      <?php
        $slots = array(
          array('before','Foto SEBELUM Dibersihkan', true),
          array('after','Foto SESUDAH Dibersihkan', true),
          array('temuan','Foto TEMUAN (opsional) — kaca/keramik pecah, dll', false),
        );
        foreach ($slots as $s): list($key,$label,$req)=$s; ?>
        <div class="photo-box">
          <label><?= e($label) ?> <?= $req?'<span style="color:var(--danger)">*</span>':'<span style="color:var(--muted)">(opsional)</span>' ?></label>
          <input type="file" name="photo_<?= $key ?>" id="file_<?= $key ?>" accept="image/*" capture="environment" hidden>
          <div class="cam-wrap" id="wrap_<?= $key ?>">
            <video id="video_<?= $key ?>" autoplay playsinline muted style="display:none"></video>
            <img id="img_<?= $key ?>" style="display:none">
            <canvas id="canvas_<?= $key ?>" style="display:none"></canvas>
            <div class="cam-empty" id="empty_<?= $key ?>">
              <button type="button" class="btn btn-ghost cam-open" data-key="<?= $key ?>" style="width:auto">📷 Buka Kamera</button>
            </div>
          </div>
          <div class="cam-actions" id="act_<?= $key ?>" style="display:none">
            <button type="button" class="btn btn-primary cam-shot" data-key="<?= $key ?>" style="width:auto">Ambil Foto</button>
            <button type="button" class="btn btn-ghost cam-retake" data-key="<?= $key ?>" style="width:auto;display:none">Ulangi</button>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="field" id="temuanNoteWrap" style="display:none">
      <label>Keterangan Temuan</label>
      <input type="text" name="temuan_note" placeholder="cth: Kaca depan pecah di sisi kanan"
        style="width:100%;padding:11px;border:1.5px solid var(--line);border-radius:10px">
    </div>

    <button type="submit" class="btn btn-primary" id="submitBtn" style="width:auto;margin-top:8px">Kirim Laporan</button>
  </form>
</div>

<style>
  .form-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}
  .photo-grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;margin:16px 0}
  .photo-box label{display:block;font-size:13px;font-weight:600;margin-bottom:6px}
  .cam-wrap{border:2px dashed var(--line);border-radius:12px;height:220px;background:#0c1622;overflow:hidden;position:relative;display:grid;place-items:center}
  .cam-wrap video,.cam-wrap img{width:100%;height:100%;object-fit:cover}
  .cam-empty{position:absolute;inset:0;display:grid;place-items:center;background:#f7f9fc}
  .cam-actions{display:flex;gap:8px;margin-top:8px}
  .gps-status{background:var(--blue-100);color:var(--blue-800);padding:10px 14px;border-radius:10px;font-size:13px;font-weight:600}
  .gps-status.ok{background:#e8f7ef;color:#13703f}.gps-status.err{background:#fdecea;color:#a32219}
  .gps-dist{margin-top:8px;padding:10px 14px;border-radius:10px;font-size:13px;font-weight:600}
  .gps-dist.ok{background:#e8f7ef;color:#13703f}.gps-dist.warn{background:#fdecea;color:#a32219}
  .ac-list{position:absolute;left:0;right:0;top:100%;background:#fff;border:1px solid var(--line);border-radius:10px;
    box-shadow:0 8px 24px rgba(16,40,80,.12);max-height:260px;overflow-y:auto;z-index:30;display:none}
  .ac-item{padding:10px 12px;cursor:pointer;font-size:14px;border-bottom:1px solid #f0f3f8}
  .ac-item:hover,.ac-item.active{background:var(--blue-100)}
  .ac-item b{color:var(--blue-800)}
  @media(max-width:760px){.form-grid,.photo-grid{grid-template-columns:1fr}}
</style>

<script>
(function(){
  // ====== DATA ATM (untuk pencarian & jarak) ======
  var ATMS = <?= json_encode(array_map(function($a){
      return array('id'=>(int)$a['id'],'code'=>$a['code'],'name'=>$a['name'],
                   'lat'=>$a['latitude'],'lng'=>$a['longitude']);
    }, $atms), JSON_HEX_APOS|JSON_HEX_QUOT) ?>;

  var curLat=null, curLng=null, chosenAtm=null;
  var THRESHOLD = 50; // meter

  // ====== GPS ======
  var gs=document.getElementById('gpsStatus');
  function haversine(la1,lo1,la2,lo2){
    if(la1==null||lo1==null||la2==null||lo2==null) return null;
    la2=parseFloat(la2);lo2=parseFloat(lo2);
    if(isNaN(la2)||isNaN(lo2)) return null;
    var R=6371000,dLa=(la2-la1)*Math.PI/180,dLo=(lo2-lo1)*Math.PI/180;
    var a=Math.sin(dLa/2)*Math.sin(dLa/2)+Math.cos(la1*Math.PI/180)*Math.cos(la2*Math.PI/180)*Math.sin(dLo/2)*Math.sin(dLo/2);
    return Math.round(R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a)));
  }
  function updateDist(){
    var box=document.getElementById('gpsDist');
    if(!chosenAtm||curLat==null){ box.style.display='none'; return; }
    var d=haversine(curLat,curLng,chosenAtm.lat,chosenAtm.lng);
    if(d==null){ box.style.display='none'; return; }
    box.style.display='block';
    if(d<=THRESHOLD){
      box.className='gps-dist ok';
      box.innerHTML='✅ Anda berada ±'+d+' m dari ATM '+chosenAtm.code+' (dalam radius wajar).';
    }else{
      box.className='gps-dist warn';
      box.innerHTML='⚠️ Anda JAUH dari lokasi ATM '+chosenAtm.code+': ±'+d+' m (lebih dari '+THRESHOLD+' m). Pastikan Anda benar berada di lokasi ATM.';
    }
  }
  if(navigator.geolocation){
    navigator.geolocation.watchPosition(function(pos){
      var c=pos.coords; curLat=c.latitude; curLng=c.longitude;
      document.getElementById('gps_lat').value=c.latitude.toFixed(7);
      document.getElementById('gps_lng').value=c.longitude.toFixed(7);
      document.getElementById('gps_accuracy').value=Math.round(c.accuracy);
      gs.className='gps-status ok';
      gs.textContent='📍 Lokasi terkunci: '+c.latitude.toFixed(6)+', '+c.longitude.toFixed(6)+'  (±'+Math.round(c.accuracy)+' m)';
      updateDist();
    },function(){
      gs.className='gps-status err';
      gs.textContent='⚠️ GPS tidak aktif. Izinkan akses lokasi lalu muat ulang.';
    },{enableHighAccuracy:true,timeout:15000,maximumAge:0});
  }else{ gs.className='gps-status err'; gs.textContent='⚠️ Perangkat tidak mendukung GPS.'; }

  // ====== SEARCHABLE ATM ======
  var inp=document.getElementById('atmSearch'), list=document.getElementById('atmResults');
  function renderList(items){
    if(!items.length){ list.style.display='none'; return; }
    list.innerHTML='';
    items.slice(0,15).forEach(function(a){
      var div=document.createElement('div'); div.className='ac-item';
      div.innerHTML='<b>'+a.code+'</b> — '+a.name;
      div.onclick=function(){ choose(a); };
      list.appendChild(div);
    });
    list.style.display='block';
  }
  function choose(a){
    chosenAtm=a;
    document.getElementById('atm_id').value=a.id;
    inp.value=a.code+' — '+a.name;
    list.style.display='none';
    document.getElementById('atmChosen').innerHTML='✅ Dipilih: <b>'+a.code+'</b> — '+a.name;
    updateDist();
  }
  inp.addEventListener('input',function(){
    var q=inp.value.trim().toLowerCase();
    document.getElementById('atm_id').value=''; chosenAtm=null;
    document.getElementById('atmChosen').innerHTML='';
    document.getElementById('gpsDist').style.display='none';
    if(q.length<2){ list.style.display='none'; return; }
    var res=ATMS.filter(function(a){
      return a.code.toLowerCase().indexOf(q)>=0 || (a.name||'').toLowerCase().indexOf(q)>=0;
    });
    renderList(res);
  });
  document.addEventListener('click',function(e){
    if(!list.contains(e.target) && e.target!==inp) list.style.display='none';
  });

  // ====== KAMERA LIVE (blokir galeri/file di HP & desktop) ======
  var streams={};
  function openCam(key){
    var video=document.getElementById('video_'+key);
    var wrap=document.getElementById('wrap_'+key);
    var empty=document.getElementById('empty_'+key);
    var act=document.getElementById('act_'+key);
    if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia){
      alert('Browser tidak mendukung akses kamera. Gunakan Chrome/Edge terbaru dan akses via localhost atau HTTPS.');
      return;
    }
    navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}},audio:false})
      .then(function(stream){
        streams[key]=stream;
        video.srcObject=stream; video.style.display='block';
        document.getElementById('img_'+key).style.display='none';
        empty.style.display='none'; act.style.display='flex';
        act.querySelector('.cam-shot').style.display='inline-flex';
        act.querySelector('.cam-retake').style.display='none';
      })
      .catch(function(err){
        alert('Tidak bisa membuka kamera: '+err.message+'\nPastikan izin kamera diberikan dan akses via localhost/HTTPS.');
      });
  }
  function shoot(key){
    var video=document.getElementById('video_'+key);
    var canvas=document.getElementById('canvas_'+key);
    var img=document.getElementById('img_'+key);
    var w=video.videoWidth, h=video.videoHeight;
    if(!w||!h){ alert('Kamera belum siap, tunggu sebentar.'); return; }
    canvas.width=w; canvas.height=h;
    canvas.getContext('2d').drawImage(video,0,0,w,h);
    var dataUrl=canvas.toDataURL('image/jpeg',0.9);
    img.src=dataUrl; img.style.display='block'; video.style.display='none';
    // hentikan stream
    if(streams[key]){ streams[key].getTracks().forEach(function(t){t.stop();}); streams[key]=null; }
    // konversi dataURL -> File ke input file (agar terkirim via form)
    canvas.toBlob(function(blob){
      var file=new File([blob],'cam_'+key+'_'+Date.now()+'.jpg',{type:'image/jpeg'});
      var dt=new DataTransfer(); dt.items.add(file);
      document.getElementById('file_'+key).files=dt.files;
    },'image/jpeg',0.9);
    var act=document.getElementById('act_'+key);
    act.querySelector('.cam-shot').style.display='none';
    act.querySelector('.cam-retake').style.display='inline-flex';
    if(key==='temuan'){ document.getElementById('temuanNoteWrap').style.display='block'; }
  }
  function retake(key){ openCam(key); document.getElementById('img_'+key).style.display='none'; }

  document.querySelectorAll('.cam-open').forEach(function(b){ b.onclick=function(){ openCam(b.dataset.key); }; });
  document.querySelectorAll('.cam-shot').forEach(function(b){ b.onclick=function(){ shoot(b.dataset.key); }; });
  document.querySelectorAll('.cam-retake').forEach(function(b){ b.onclick=function(){ retake(b.dataset.key); }; });

  // Blokir total input file dari interaksi manual (anti galeri):
  ['before','after','temuan'].forEach(function(key){
    var fi=document.getElementById('file_'+key);
    fi.addEventListener('click',function(e){ e.preventDefault(); }); // tak bisa dibuka manual
  });

  // ====== VALIDASI SUBMIT ======
  document.getElementById('reportForm').addEventListener('submit',function(e){
    if(!document.getElementById('atm_id').value){
      e.preventDefault(); alert('Silakan cari & pilih ATM terlebih dahulu.'); return;
    }
    var b=document.getElementById('file_before').files.length;
    var a=document.getElementById('file_after').files.length;
    if(!b||!a){
      e.preventDefault();
      alert('Foto SEBELUM dan SESUDAH wajib diambil melalui kamera sebelum mengirim laporan.');
      return;
    }
    document.getElementById('submitBtn').textContent='Mengirim…';
    document.getElementById('submitBtn').disabled=true;
  });
})();
</script>
