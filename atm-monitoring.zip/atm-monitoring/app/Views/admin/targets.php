<?php /** admin/targets.php */ ?>
<?php if(!empty($success)): ?><div class="alert alert-ok" style="margin-bottom:12px"><?= e($success) ?></div><?php endif; ?>
<div class="panel">
  <h3>Target Kebersihan Harian</h3>
  <form method="post" action="<?= url('admin/targets/store') ?>" style="display:flex;gap:8px;flex-wrap:wrap;margin:12px 0">
    <?= csrf_field() ?>
    <input type="date" name="target_date" required style="padding:9px;border:1.5px solid var(--line);border-radius:9px">
    <select name="region_id" style="padding:9px;border:1.5px solid var(--line);border-radius:9px">
      <option value="">Global (semua region)</option>
      <?php foreach($regions as $r): ?><option value="<?= $r['id'] ?>"><?= e($r['name']) ?></option><?php endforeach; ?>
    </select>
    <input type="number" name="target_count" min="0" placeholder="Jumlah ATM" required style="padding:9px;border:1.5px solid var(--line);border-radius:9px">
    <button class="btn btn-primary" style="width:auto">Simpan Target</button>
  </form>
  <table class="tbl">
    <thead><tr><th>Tanggal</th><th>Region</th><th>Target ATM</th></tr></thead>
    <tbody>
    <?php foreach($rows as $r): ?>
      <tr><td><?= e(tgl_id($r['target_date'])) ?></td><td><?= e(isset($r['region_name'])?$r['region_name']:'Global') ?></td><td><b><?= (int)$r['target_count'] ?></b></td></tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<style>.tbl{width:100%;border-collapse:collapse;font-size:13.5px}.tbl th{text-align:left;background:#f4f7fb;color:#46546a;padding:10px;border-bottom:2px solid var(--line);font-size:12px;text-transform:uppercase}.tbl td{padding:10px;border-bottom:1px solid #eef2f7}</style>
