<?php /** admin/logs.php */ ?>
<div class="panel">
  <h3>Audit Log Aktivitas (200 terakhir)</h3>
  <div style="overflow-x:auto">
  <table class="tbl">
    <thead><tr><th>Waktu</th><th>User</th><th>Aksi</th><th>Entitas</th><th>Deskripsi</th><th>IP</th></tr></thead>
    <tbody>
    <?php foreach($rows as $l): ?>
      <tr>
        <td style="white-space:nowrap;font-size:12px"><?= e(tgl_id($l['created_at'],true)) ?></td>
        <td><?= e(isset($l['user_name'])?$l['user_name']:'-') ?></td>
        <td><span style="background:#eef2f8;padding:2px 8px;border-radius:6px;font-size:12px"><?= e($l['action']) ?></span></td>
        <td style="font-size:12px"><?= e(isset($l['entity'])?$l['entity']:'-') ?><?= $l['entity_id']?' #'.e($l['entity_id']):'' ?></td>
        <td style="font-size:13px"><?= e(isset($l['description'])?$l['description']:'') ?></td>
        <td style="font-size:12px;color:var(--muted)"><?= e(isset($l['ip_address'])?$l['ip_address']:'') ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
</div>
<style>.tbl{width:100%;border-collapse:collapse;font-size:13.5px}.tbl th{text-align:left;background:#f4f7fb;color:#46546a;padding:10px;border-bottom:2px solid var(--line);font-size:12px;text-transform:uppercase}.tbl td{padding:10px;border-bottom:1px solid #eef2f7}</style>
