<?php /** admin/dashboard.php */ $s=$stats; ?>
<div class="cards">
  <div class="card accent"><div class="k">Total ATM</div><div class="v"><?= $s['totalAtm'] ?></div></div>
  <div class="card"><div class="k">Sudah Dibersihkan</div><div class="v" style="color:var(--ok)"><?= $s['sudah'] ?></div></div>
  <div class="card"><div class="k">Belum Dibersihkan</div><div class="v" style="color:var(--danger)"><?= $s['belum'] ?></div></div>
  <div class="card"><div class="k">Petugas Aktif</div><div class="v"><?= $s['petugasAktif'] ?></div></div>
  <div class="card"><div class="k">Laporan Hari Ini</div><div class="v"><?= $s['laporanHariIni'] ?></div></div>
  <div class="card"><div class="k">Target Hari Ini</div><div class="v"><?= $s['target'] ?></div></div>
</div>

<div class="panel">
  <h3>Progress Penyelesaian Hari Ini — <?= $s['persen'] ?>%</h3>
  <div class="progress"><span style="width:<?= min(100,$s['persen']) ?>%"></span></div>
  <p style="margin-top:10px;color:var(--muted);font-size:13px"><?= $s['sudah'] ?> dari <?= $s['target'] ?> target ATM telah dibersihkan.</p>
</div>

<div class="panel">
  <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:8px">
    <h3 id="trendTitle" style="margin:0">Grafik Laporan</h3>
    <div class="seg">
      <button type="button" class="seg-btn active" data-period="week">Mingguan</button>
      <button type="button" class="seg-btn" data-period="month">Bulanan</button>
      <button type="button" class="seg-btn" data-period="year">Tahunan</button>
    </div>
  </div>
  <div style="height:280px"><canvas id="chartTrend"></canvas></div>
</div>

<div class="panel">
  <h3>Penyelesaian per Area Hari Ini</h3>
  <div style="height:300px"><canvas id="chartArea"></canvas></div>
</div>

<div style="display:flex;gap:12px;flex-wrap:wrap">
  <a class="btn btn-primary" style="width:auto" href="<?= url('supervisor/map') ?>">Lihat Peta Monitoring</a>
  <a class="btn btn-ghost" style="width:auto" href="<?= url('reports') ?>">Lihat Semua Laporan</a>
</div>

<?php if($s['belum']>0): ?>
<div id="notifPop" class="notif-pop">
  <b>⚠️ Notifikasi</b>
  <p>Masih terdapat <b><?= $s['belum'] ?></b> ATM yang belum dibersihkan hari ini.</p>
  <button onclick="document.getElementById('notifPop').remove()">Tutup</button>
</div>
<?php endif; ?>

<style>
.notif-pop{position:fixed;right:24px;bottom:24px;background:#fff;border-left:5px solid var(--danger);
  box-shadow:0 8px 30px rgba(16,40,80,.18);border-radius:12px;padding:16px 18px;max-width:320px;z-index:80}
.notif-pop p{font-size:13.5px;color:#46546a;margin:6px 0 10px}
.notif-pop button{background:#eef2f8;border:none;border-radius:8px;padding:7px 14px;cursor:pointer;font-weight:600;font-size:13px}
.seg{display:inline-flex;background:#eef2f8;border-radius:9px;padding:3px}
.seg-btn{border:none;background:none;padding:7px 14px;border-radius:7px;cursor:pointer;font-size:13px;font-weight:600;color:#46546a}
.seg-btn.active{background:#fff;color:var(--blue-700);box-shadow:0 1px 3px rgba(16,40,80,.12)}
</style>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
(function(){
  var trendChart=null;
  function loadTrend(period){
    fetch('<?= url('api/monitoring/chart') ?>?period='+period).then(function(r){return r.json();}).then(function(d){
      var labels=[],vals=[];
      (d.rows||[]).forEach(function(x){ labels.push(String(x.d).substring(5)); vals.push(parseInt(x.c)); });
      document.getElementById('trendTitle').textContent = d.label || 'Grafik Laporan';
      if(trendChart) trendChart.destroy();
      trendChart=new Chart(document.getElementById('chartTrend'),{
        type:'bar',
        data:{labels:labels,datasets:[{label:'Jumlah Laporan',data:vals,backgroundColor:'#0061c2',borderRadius:6}]},
        options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},
                 scales:{y:{beginAtZero:true,ticks:{precision:0}}}}
      });
    });
  }
  var btns=document.querySelectorAll('.seg-btn');
  btns.forEach(function(b){ b.addEventListener('click',function(){
    btns.forEach(function(x){x.classList.remove('active');});
    b.classList.add('active'); loadTrend(b.getAttribute('data-period'));
  });});
  loadTrend('week');

  // grafik per area (stacked: sudah vs sisa)
  fetch('<?= url('api/monitoring/chart-area') ?>').then(function(r){return r.json();}).then(function(d){
    var labels=[],sudah=[],sisa=[];
    (d.rows||[]).forEach(function(x){
      labels.push(x.area||'-'); var t=parseInt(x.total)||0,s=parseInt(x.sudah)||0;
      sudah.push(s); sisa.push(Math.max(0,t-s));
    });
    new Chart(document.getElementById('chartArea'),{
      type:'bar',
      data:{labels:labels,datasets:[
        {label:'Sudah Dibersihkan',data:sudah,backgroundColor:'#1aa260',borderRadius:4},
        {label:'Belum',data:sisa,backgroundColor:'#e0392b',borderRadius:4}
      ]},
      options:{responsive:true,maintainAspectRatio:false,
               scales:{x:{stacked:true},y:{stacked:true,beginAtZero:true,ticks:{precision:0}}}}
    });
  });
})();
</script>
