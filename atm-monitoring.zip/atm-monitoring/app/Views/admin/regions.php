<?php /** admin/regions.php — kelola AREA (kota) */ ?>
<?php if(!empty($success)): ?><div class="alert alert-ok" style="margin-bottom:12px"><?= e($success) ?></div><?php endif; ?>
<?php if(!empty($error)): ?><div class="alert alert-error" style="margin-bottom:12px"><?= e($error) ?></div><?php endif; ?>
<div class="panel">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
    <h3 style="margin:0">Kelola Area</h3>
    <button class="btn btn-primary" style="width:auto" onclick="openArea()">+ Tambah Area</button>
  </div>
  <p style="color:var(--muted);font-size:13px;margin-bottom:14px">Area adalah wilayah operasional seperti Banjarmasin, Pontianak, Samarinda, Balikpapan, Palangkaraya.</p>
  <table class="tbl">
    <thead><tr><th>Nama Area</th><th>Jumlah ATM</th><th>Aksi</th></tr></thead>
    <tbody>
    <?php foreach($rows as $r): ?>
      <tr>
        <td><b><?= e($r['name']) ?></b></td>
        <td><?= (int)$r['atm_count'] ?></td>
        <td style="white-space:nowrap">
          <button class="link-btn" onclick="editArea(<?= (int)$r['id'] ?>,'<?= e(addslashes($r['name'])) ?>')">Edit</button>
          <form method="post" action="<?= url('admin/regions/delete') ?>" style="display:inline" onsubmit="return confirm('Hapus area ini?')">
            <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
            <button class="link-btn danger">Hapus</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if(!$rows): ?><tr><td colspan="3" style="text-align:center;color:var(--muted);padding:24px">Belum ada area.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>

<div class="modal-bg" id="areaModal">
  <div class="modal">
    <h3 id="aTitle">Tambah Area</h3>
    <form method="post" action="<?= url('admin/regions/store') ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="id" id="a_id">
      <div class="field"><label>Nama Area</label><input name="name" id="a_name" required placeholder="cth: Tarakan"></div>
      <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:8px">
        <button type="button" class="btn btn-ghost" style="width:auto" onclick="closeArea()">Batal</button>
        <button class="btn btn-primary" style="width:auto">Simpan</button>
      </div>
    </form>
  </div>
</div>

<style>.tbl{width:100%;border-collapse:collapse;font-size:13.5px}.tbl th{text-align:left;background:#f4f7fb;color:#46546a;padding:10px;border-bottom:2px solid var(--line);font-size:12px;text-transform:uppercase}.tbl td{padding:10px;border-bottom:1px solid #eef2f7}.link-btn{background:none;border:none;color:var(--blue-700);cursor:pointer;font-weight:600;font-size:13px;padding:2px 4px}.link-btn.danger{color:var(--danger)}
.field label{display:block;font-size:12px;font-weight:600;margin-bottom:5px}.field input{width:100%;padding:10px;border:1.5px solid var(--line);border-radius:9px}
.modal-bg{display:none;position:fixed;inset:0;background:rgba(16,30,55,.5);z-index:100;align-items:flex-start;justify-content:center;padding:60px 16px}.modal-bg.open{display:flex}.modal{background:#fff;border-radius:14px;padding:24px;width:100%;max-width:420px}.modal h3{margin-bottom:16px}</style>
<script>
  var am=document.getElementById('areaModal');
  function openArea(){document.getElementById('aTitle').textContent='Tambah Area';document.getElementById('a_id').value='';document.getElementById('a_name').value='';am.classList.add('open');}
  function editArea(id,name){document.getElementById('aTitle').textContent='Edit Area';document.getElementById('a_id').value=id;document.getElementById('a_name').value=name;am.classList.add('open');}
  function closeArea(){am.classList.remove('open');}
  am.addEventListener('click',function(e){if(e.target===am)closeArea();});
</script>
