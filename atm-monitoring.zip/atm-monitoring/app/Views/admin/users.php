<?php /** admin/users.php */ ?>
<?php if(!empty($success)): ?><div class="alert alert-ok" style="margin-bottom:12px"><?= e($success) ?></div><?php endif; ?>
<?php if(!empty($error)): ?><div class="alert alert-error" style="margin-bottom:12px"><?= e($error) ?></div><?php endif; ?>
<div class="panel">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
    <h3 style="margin:0">Kelola User</h3>
    <button class="btn btn-primary" style="width:auto" onclick="openUser()">+ Tambah User</button>
  </div>
  <div style="overflow-x:auto">
  <table class="tbl">
    <thead><tr><th>Nama</th><th>Username</th><th>Role</th><th>Area</th><th>Status</th><th>Login Terakhir</th><th>Aksi</th></tr></thead>
    <tbody>
    <?php foreach($rows as $u): ?>
      <tr>
        <td><b><?= e($u['name']) ?></b><br><small style="color:var(--muted)"><?= e(isset($u['nip'])?$u['nip']:'') ?></small></td>
        <td><?= e($u['username']) ?></td>
        <td><?= e($u['role_label']) ?></td>
        <td><?= e(isset($u['region_name'])?$u['region_name']:'-') ?></td>
        <td><?= $u['is_active']?'<span style="color:var(--ok);font-weight:600">Aktif</span>':'<span style="color:var(--danger)">Nonaktif</span>' ?></td>
        <td style="font-size:12px"><?= $u['last_login_at']?e(tgl_id($u['last_login_at'],true)):'-' ?></td>
        <td style="white-space:nowrap">
          <button class="link-btn" onclick='editUser(<?= json_encode($u, JSON_HEX_APOS|JSON_HEX_QUOT) ?>)'>Edit</button>
          <form method="post" action="<?= url('admin/users/toggle') ?>" style="display:inline">
            <?= csrf_field() ?><input type="hidden" name="id" value="<?= $u['id'] ?>">
            <button class="link-btn"><?= $u['is_active']?'Nonaktifkan':'Aktifkan' ?></button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>
</div>

<!-- Modal Tambah/Edit User -->
<div class="modal-bg" id="userModal">
  <div class="modal">
    <h3 id="uModalTitle">Tambah User</h3>
    <form method="post" id="userForm" action="<?= url('admin/users/store') ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="id" id="u_id">
      <div class="mg">
        <div class="field"><label>Nama</label><input name="name" id="u_name" required></div>
        <div class="field"><label>Username</label><input name="username" id="u_username" required></div>
      </div>
      <div class="mg">
        <div class="field">
          <label>Password <small id="u_pwhint" style="color:var(--muted)"></small></label>
          <input name="password" id="u_password" type="text">
        </div>
        <div class="field"><label>Role</label>
          <select name="role_id" id="u_role" required>
            <option value="2">Supervisor</option><option value="3">Petugas</option><option value="1">Admin</option>
          </select>
        </div>
      </div>
      <div class="mg">
        <div class="field"><label>Area / Region</label>
          <select name="region_id" id="u_region"><option value="">—</option>
            <?php foreach($regions as $r): ?><option value="<?= $r['id'] ?>"><?= e($r['name']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="field"><label>NIP</label><input name="nip" id="u_nip"></div>
      </div>
      <div class="mg">
        <div class="field"><label>Email</label><input name="email" id="u_email" type="email"></div>
        <div class="field"><label>Telepon</label><input name="phone" id="u_phone"></div>
      </div>
      <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:8px">
        <button type="button" class="btn btn-ghost" style="width:auto" onclick="closeUser()">Batal</button>
        <button class="btn btn-primary" style="width:auto">Simpan</button>
      </div>
    </form>
  </div>
</div>

<style>.tbl{width:100%;border-collapse:collapse;font-size:13.5px}.tbl th{text-align:left;background:#f4f7fb;color:#46546a;padding:10px;border-bottom:2px solid var(--line);font-size:12px;text-transform:uppercase}.tbl td{padding:10px;border-bottom:1px solid #eef2f7;vertical-align:top}.link-btn{background:none;border:none;color:var(--blue-700);cursor:pointer;font-weight:600;font-size:13px;padding:2px 4px}
.mg{display:grid;grid-template-columns:1fr 1fr;gap:12px}.mg input,.mg select{width:100%;padding:10px;border:1.5px solid var(--line);border-radius:9px;font-size:14px}.mg .field{margin-bottom:12px}.mg .field label{display:block;font-size:12px;font-weight:600;margin-bottom:5px}
.modal-bg{display:none;position:fixed;inset:0;background:rgba(16,30,55,.5);z-index:100;align-items:flex-start;justify-content:center;overflow-y:auto;padding:30px 16px}.modal-bg.open{display:flex}
.modal{background:#fff;border-radius:14px;padding:24px;width:100%;max-width:560px}.modal h3{margin-bottom:16px}</style>

<script>
  var um = document.getElementById('userModal');
  var uf = document.getElementById('userForm');
  function openUser(){
    document.getElementById('uModalTitle').textContent='Tambah User';
    uf.action='<?= url('admin/users/store') ?>'; uf.reset();
    document.getElementById('u_id').value='';
    document.getElementById('u_password').required=true;
    document.getElementById('u_pwhint').textContent='(wajib)';
    um.classList.add('open');
  }
  function editUser(u){
    document.getElementById('uModalTitle').textContent='Edit User';
    uf.action='<?= url('admin/users/update') ?>';
    document.getElementById('u_id').value=u.id;
    document.getElementById('u_name').value=u.name||'';
    document.getElementById('u_username').value=u.username||'';
    document.getElementById('u_role').value=u.role_id||'';
    document.getElementById('u_region').value=u.region_id||'';
    document.getElementById('u_nip').value=u.nip||'';
    document.getElementById('u_email').value=u.email||'';
    document.getElementById('u_phone').value=u.phone||'';
    document.getElementById('u_password').value='';
    document.getElementById('u_password').required=false;
    document.getElementById('u_pwhint').textContent='(kosongkan jika tidak diubah)';
    um.classList.add('open');
  }
  function closeUser(){ um.classList.remove('open'); }
  um.addEventListener('click',function(e){ if(e.target===um) closeUser(); });
</script>
