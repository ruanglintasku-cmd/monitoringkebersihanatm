<?php /** admin/atm_index.php */
$d = $data; $rows = $d['rows'];
function statusBadge($s){
  $map=['aktif'=>['#e8f7ef','#13703f','Aktif'],'nonaktif'=>['#fdecea','#a32219','Nonaktif'],
        'maintenance'=>['#fff6e5','#9a6700','Maintenance']];
  $c=isset($map[$s])?$map[$s]:array('#eef2f8','#33404f',$s);
  return '<span style="background:'.$c[0].';color:'.$c[1].';padding:3px 10px;border-radius:99px;font-size:12px;font-weight:600">'.e($c[2]).'</span>';
}
?>
<?php if (!empty($success)): ?><div class="alert alert-ok" style="margin-bottom:14px"><?= e($success) ?></div><?php endif; ?>
<?php if (!empty($error)): ?><div class="alert alert-error" style="margin-bottom:14px"><?= e($error) ?></div><?php endif; ?>

<div class="panel">
  <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;margin-bottom:14px">
    <h3 style="margin:0">Data ATM (<?= (int)$d['total'] ?>)</h3>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button class="btn btn-primary" style="width:auto" onclick="openAtm()">+ Tambah ATM</button>
      <a class="btn btn-ghost" style="width:auto" href="<?= url('admin/atm/export') ?>">Export Excel</a>
      <button class="btn btn-ghost" style="width:auto" onclick="document.getElementById('importBox').classList.toggle('hide')">Import CSV</button>
    </div>
  </div>

  <div id="importBox" class="hide" style="background:#f7f9fc;border:1px dashed var(--line);border-radius:10px;padding:14px;margin-bottom:14px">
    <form method="post" action="<?= url('admin/atm/import') ?>" enctype="multipart/form-data" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
      <?= csrf_field() ?>
      <input type="file" name="file" accept=".csv" required>
      <button class="btn btn-primary" style="width:auto">Upload</button>
      <small style="color:var(--muted)">Header CSV dikenali otomatis (Kode/Terminal ID, Nama/Lokasi, Area, Alamat, Latitude, Longitude, Tipe Mesin, dll). Kode ATM yang sudah ada akan diperbarui.</small>
    </form>
  </div>

  <!-- Filter -->
  <form method="get" action="<?= url('admin/atm') ?>" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px">
    <input type="text" name="q" value="<?= e($f['q']) ?>" placeholder="Cari kode / nama / alamat…"
      style="flex:1;min-width:180px;padding:9px 12px;border:1.5px solid var(--line);border-radius:9px">
    <select name="region_id" style="padding:9px;border:1.5px solid var(--line);border-radius:9px">
      <option value="">Semua Region</option>
      <?php foreach ($regions as $r): ?>
        <option value="<?= $r['id'] ?>" <?= $f['region_id']==$r['id']?'selected':'' ?>><?= e($r['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select name="status" style="padding:9px;border:1.5px solid var(--line);border-radius:9px">
      <option value="">Semua Status</option>
      <?php foreach (['aktif','nonaktif','maintenance'] as $s): ?>
        <option value="<?= $s ?>" <?= $f['status']===$s?'selected':'' ?>><?= ucfirst($s) ?></option>
      <?php endforeach; ?>
    </select>
    <button class="btn btn-primary" style="width:auto">Cari</button>
  </form>

  <div style="overflow-x:auto">
    <table class="tbl">
      <thead><tr>
        <th>Kode</th><th>Nama</th><th>Kota</th><th>Tipe</th><th>Pengelola</th><th>Alamat</th>
        <th>Koordinat</th><th>Status</th><th>Petugas</th><th>Aksi</th>
      </tr></thead>
      <tbody>
        <?php if (!$rows): ?>
          <tr><td colspan="10" style="text-align:center;color:var(--muted);padding:24px">Belum ada data ATM.</td></tr>
        <?php endif; ?>
        <?php foreach ($rows as $a): ?>
          <tr>
            <td><b><?= e($a['code']) ?></b></td>
            <td><?= e($a['name']) ?></td>
            <td><?= e(isset($a['city_name'])?$a['city_name']:'-') ?></td>
            <td><?= e(isset($a['tipe_mesin'])?$a['tipe_mesin']:'-') ?></td>
            <td><?= e(isset($a['nama_pengelola'])?$a['nama_pengelola']:(isset($a['pengelola'])?$a['pengelola']:'-')) ?></td>
            <td style="max-width:220px"><?= e($a['address']) ?></td>
            <td style="font-size:12px;color:var(--muted)">
              <?php if($a['latitude']!=='' && $a['latitude']!==null): ?>
                <a href="https://www.google.com/maps?q=<?= e($a['latitude']) ?>,<?= e($a['longitude']) ?>" target="_blank" style="color:var(--blue-700);font-weight:600" title="Buka di Google Maps"><?= e($a['latitude']) ?>,<br><?= e($a['longitude']) ?> 📍</a>
              <?php else: ?>-<?php endif; ?>
            </td>
            <td><?= statusBadge($a['status']) ?></td>
            <td><?= e(isset($a['petugas_name'])?$a['petugas_name']:'-') ?></td>
            <td style="white-space:nowrap">
              <button class="link-btn" onclick='editAtm(<?= json_encode($a, JSON_HEX_APOS|JSON_HEX_QUOT) ?>)'>Edit</button>
              <form method="post" action="<?= url('admin/atm/delete') ?>" style="display:inline" onsubmit="return confirm('Hapus ATM ini?')">
                <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
                <button class="link-btn danger">Hapus</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <?php if ($d['pages']>1): ?>
  <div style="display:flex;gap:6px;margin-top:14px;flex-wrap:wrap">
    <?php for ($i=1;$i<=$d['pages'];$i++): ?>
      <a href="<?= url('admin/atm?page='.$i.'&q='.urlencode($f['q'])) ?>"
         class="page-link <?= $i==$d['page']?'active':'' ?>"><?= $i ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>

<!-- Modal Add/Edit -->
<div class="modal-bg" id="atmModal">
  <div class="modal">
    <h3 id="modalTitle">Tambah ATM</h3>
    <form method="post" id="atmForm" action="<?= url('admin/atm/store') ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="id" id="m_id">
      <div class="mg">
        <div class="field"><label>Kode ATM</label><input name="code" id="m_code" required></div>
        <div class="field"><label>Nama ATM</label><input name="name" id="m_name" required></div>
      </div>
      <div class="mg">
        <div class="field"><label>Region</label>
          <select name="region_id" id="m_region" required>
            <?php foreach ($regions as $r): ?><option value="<?= $r['id'] ?>"><?= e($r['name']) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="field"><label>Kota</label>
          <select name="city_id" id="m_city"><option value="">—</option>
            <?php foreach ($cities as $c): ?><option value="<?= $c['id'] ?>"><?= e($c['name']) ?></option><?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="field"><label>Area</label><input name="area" id="m_area"></div>
      <div class="field"><label>Alamat Lengkap</label><input name="address" id="m_address"></div>
      <div class="mg">
        <div class="field"><label>Latitude</label><input name="latitude" id="m_lat" placeholder="-1.2654"></div>
        <div class="field"><label>Longitude</label><input name="longitude" id="m_lng" placeholder="116.8312"></div>
      </div>
      <div class="mg">
        <div class="field"><label>Status</label>
          <select name="status" id="m_status">
            <option value="aktif">Aktif</option><option value="nonaktif">Nonaktif</option><option value="maintenance">Maintenance</option>
          </select>
        </div>
        <div class="field"><label>Target Harian</label><input type="number" name="daily_target" id="m_target" value="1" min="1"></div>
      </div>
      <div class="field"><label>Petugas Penanggung Jawab</label>
        <select name="assigned_to" id="m_assigned"><option value="">—</option>
          <?php foreach ($petugas as $p): ?><option value="<?= $p['id'] ?>"><?= e($p['name']) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:8px">
        <button type="button" class="btn btn-ghost" style="width:auto" onclick="closeAtm()">Batal</button>
        <button class="btn btn-primary" style="width:auto">Simpan</button>
      </div>
    </form>
  </div>
</div>

<style>
  .tbl{width:100%;border-collapse:collapse;font-size:13.5px}
  .tbl th{text-align:left;background:#f4f7fb;color:#46546a;padding:10px;border-bottom:2px solid var(--line);font-size:12px;text-transform:uppercase;letter-spacing:.02em}
  .tbl td{padding:10px;border-bottom:1px solid #eef2f7;vertical-align:top}
  .tbl tr:hover td{background:#fafcff}
  .link-btn{background:none;border:none;color:var(--blue-700);cursor:pointer;font-weight:600;font-size:13px;padding:2px 4px}
  .link-btn.danger{color:var(--danger)}
  .page-link{padding:7px 12px;border:1px solid var(--line);border-radius:8px;color:#33404f;font-size:13px}
  .page-link.active{background:var(--blue-700);color:#fff;border-color:var(--blue-700)}
  .hide{display:none}
  .mg{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  .modal-bg{display:none;position:fixed;inset:0;background:rgba(16,30,55,.5);z-index:100;align-items:flex-start;justify-content:center;overflow-y:auto;padding:30px 16px}
  .modal-bg.open{display:flex}
  .modal{background:#fff;border-radius:14px;padding:24px;width:100%;max-width:560px}
  .modal h3{margin-bottom:16px}
  .modal input,.modal select{width:100%;padding:10px;border:1.5px solid var(--line);border-radius:9px;font-size:14px}
  .modal .field{margin-bottom:12px}
</style>

<script>
  var modal = document.getElementById('atmModal');
  var form  = document.getElementById('atmForm');
  function openAtm(){
    document.getElementById('modalTitle').textContent='Tambah ATM';
    form.action='<?= url('admin/atm/store') ?>'; form.reset();
    document.getElementById('m_id').value='';
    modal.classList.add('open');
  }
  function editAtm(a){
    document.getElementById('modalTitle').textContent='Edit ATM';
    form.action='<?= url('admin/atm/update') ?>';
    document.getElementById('m_id').value=a.id;
    document.getElementById('m_code').value=a.code||'';
    document.getElementById('m_name').value=a.name||'';
    document.getElementById('m_region').value=a.region_id||'';
    document.getElementById('m_city').value=a.city_id||'';
    document.getElementById('m_area').value=a.area||'';
    document.getElementById('m_address').value=a.address||'';
    document.getElementById('m_lat').value=a.latitude||'';
    document.getElementById('m_lng').value=a.longitude||'';
    document.getElementById('m_status').value=a.status||'aktif';
    document.getElementById('m_target').value=a.daily_target||1;
    document.getElementById('m_assigned').value=a.assigned_to||'';
    modal.classList.add('open');
  }
  function closeAtm(){ modal.classList.remove('open'); }
  modal.addEventListener('click',function(e){ if(e.target===modal) closeAtm(); });
</script>
