<?php /** admin/schedule.php */ ?>
<?php if(!empty($success)): ?><div class="alert alert-ok" style="margin-bottom:12px"><?= e($success) ?></div><?php endif; ?>
<?php if(!empty($error)): ?><div class="alert alert-error" style="margin-bottom:12px"><?= e($error) ?></div><?php endif; ?>

<div class="panel">
  <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:14px">
    <h3 style="margin:0">Penjadwalan & Rotasi Tugas</h3>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button class="btn btn-primary" style="width:auto" onclick="document.getElementById('addBox').classList.toggle('hide')">+ Tambah Jadwal</button>
    </div>
  </div>

  <!-- Filter tanggal & area -->
  <form method="get" action="<?= url('admin/schedule') ?>" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px">
    <input type="date" name="date" value="<?= e($date) ?>" style="padding:9px;border:1.5px solid var(--line);border-radius:9px">
    <select name="city_id" style="padding:9px;border:1.5px solid var(--line);border-radius:9px">
      <option value="">Semua Area</option>
      <?php foreach($cities as $c): ?><option value="<?= $c['id'] ?>" <?= $cityId==$c['id']?'selected':'' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
    </select>
    <button class="btn btn-primary" style="width:auto">Tampilkan</button>
  </form>

  <!-- Auto rotasi -->
  <div style="background:#eef6ff;border:1px solid #cfe3fb;border-radius:10px;padding:14px;margin-bottom:14px">
    <b style="font-size:14px">Rotasi Otomatis</b>
    <p style="font-size:13px;color:#46546a;margin:6px 0 10px">Bagikan seluruh ATM aktif ke petugas secara bergiliran untuk tanggal terpilih. Rotasi bergeser tiap hari agar petugas tidak selalu kebagian ATM yang sama.</p>
    <form method="post" action="<?= url('admin/schedule/auto') ?>" style="display:inline" onsubmit="return confirm('Buat jadwal otomatis untuk <?= e($date) ?>? Jadwal lama tanggal ini pada ATM yang sama akan ditimpa.')">
      <?= csrf_field() ?>
      <input type="hidden" name="schedule_date" value="<?= e($date) ?>">
      <input type="hidden" name="city_id" value="<?= (int)$cityId ?>">
      <button class="btn btn-primary" style="width:auto">Jalankan Auto-Rotasi</button>
    </form>
    <form method="post" action="<?= url('admin/schedule/clear') ?>" style="display:inline" onsubmit="return confirm('Hapus SEMUA jadwal pada <?= e($date) ?>?')">
      <?= csrf_field() ?><input type="hidden" name="schedule_date" value="<?= e($date) ?>">
      <button class="btn btn-ghost" style="width:auto">Kosongkan Jadwal Tanggal Ini</button>
    </form>
  </div>

  <!-- Form tambah manual -->
  <div id="addBox" class="hide" style="background:#f7f9fc;border:1px dashed var(--line);border-radius:10px;padding:14px;margin-bottom:14px">
    <form method="post" action="<?= url('admin/schedule/store') ?>" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;align-items:end">
      <?= csrf_field() ?>
      <input type="hidden" name="schedule_date" value="<?= e($date) ?>">
      <div><label style="font-size:12px;font-weight:600">ATM</label>
        <select name="atm_id" required style="width:100%;padding:9px;border:1.5px solid var(--line);border-radius:9px">
          <option value="">— pilih —</option>
          <?php foreach($atms as $a): ?><option value="<?= $a['id'] ?>"><?= e($a['code'].' — '.$a['name']) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div><label style="font-size:12px;font-weight:600">Petugas</label>
        <select name="user_id" required style="width:100%;padding:9px;border:1.5px solid var(--line);border-radius:9px">
          <option value="">— pilih —</option>
          <?php foreach($petugas as $p): ?><option value="<?= $p['id'] ?>"><?= e($p['name']) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div><label style="font-size:12px;font-weight:600">Shift</label>
        <input name="shift" placeholder="Pagi/Siang" style="width:100%;padding:9px;border:1.5px solid var(--line);border-radius:9px"></div>
      <div><button class="btn btn-primary" style="width:auto">Simpan</button></div>
    </form>
  </div>

  <div style="overflow-x:auto">
  <table class="tbl">
    <thead><tr><th>Area</th><th>Kode ATM</th><th>Nama ATM</th><th>Petugas</th><th>Shift</th><th>Status</th><th>Aksi</th></tr></thead>
    <tbody>
    <?php foreach($rows as $r): ?>
      <tr>
        <td><?= e(isset($r['area_name'])?$r['area_name']:'-') ?></td>
        <td><b><?= e($r['atm_code']) ?></b></td>
        <td><?= e($r['atm_name']) ?></td>
        <td><?= e($r['petugas_name']) ?></td>
        <td><?= e(isset($r['shift'])?$r['shift']:'-') ?></td>
        <td><?= $r['done']>0?'<span style="color:var(--ok);font-weight:600">Selesai</span>':'<span style="color:var(--danger)">Belum</span>' ?></td>
        <td>
          <form method="post" action="<?= url('admin/schedule/delete') ?>" style="display:inline" onsubmit="return confirm('Hapus jadwal ini?')">
            <?= csrf_field() ?><input type="hidden" name="id" value="<?= $r['id'] ?>"><input type="hidden" name="schedule_date" value="<?= e($date) ?>">
            <button class="link-btn danger">Hapus</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if(!$rows): ?><tr><td colspan="7" style="text-align:center;color:var(--muted);padding:24px">Belum ada jadwal untuk tanggal ini. Gunakan Auto-Rotasi atau Tambah Jadwal.</td></tr><?php endif; ?>
    </tbody>
  </table>
  </div>
  <p style="margin-top:10px;color:var(--muted);font-size:13px">Total <?= count($rows) ?> jadwal pada <?= e(tgl_id($date)) ?>.</p>
</div>
<style>.tbl{width:100%;border-collapse:collapse;font-size:13.5px}.tbl th{text-align:left;background:#f4f7fb;color:#46546a;padding:10px;border-bottom:2px solid var(--line);font-size:12px;text-transform:uppercase}.tbl td{padding:10px;border-bottom:1px solid #eef2f7}.link-btn{background:none;border:none;color:var(--blue-700);cursor:pointer;font-weight:600;font-size:13px}.link-btn.danger{color:var(--danger)}.hide{display:none}.tbl tr:hover td{background:#fafcff}</style>
