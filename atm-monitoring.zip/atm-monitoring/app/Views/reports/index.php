<?php /** reports/index.php */
function statusPill($s,$label){
  $map=['bersih'=>['#e8f7ef','#13703f'],'kurang_bersih'=>['#fff6e5','#9a6700'],
        'kotor'=>['#fdecea','#a32219'],'tidak_bisa_dibersihkan'=>['#eef2f8','#33404f']];
  $c=isset($map[$s])?$map[$s]:array('#eef2f8','#33404f');
  return '<span style="background:'.$c[0].';color:'.$c[1].';padding:3px 9px;border-radius:99px;font-size:12px;font-weight:600">'.e(isset($label[$s])?$label[$s]:$s).'</span>';
}
$qs = http_build_query(array_filter($f));
?>
<div class="panel">
  <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:14px">
    <h3 style="margin:0">Laporan Kebersihan (<?= count($rows) ?>)</h3>
    <div style="display:flex;gap:8px">
      <a class="btn btn-ghost" style="width:auto" href="<?= url('reports/export/xls?'.$qs) ?>">Export Excel</a>
      <a class="btn btn-ghost" style="width:auto" href="<?= url('reports/export/pdf?'.$qs) ?>" target="_blank">Export PDF</a>
    </div>
  </div>

  <form method="get" action="<?= url('reports') ?>" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px">
    <input type="date" name="date_from" value="<?= e($f['date_from']) ?>" style="padding:9px;border:1.5px solid var(--line);border-radius:9px">
    <input type="date" name="date_to" value="<?= e($f['date_to']) ?>" style="padding:9px;border:1.5px solid var(--line);border-radius:9px">
    <?php if (user_role()!=='petugas'): ?>
    <select name="user_id" style="padding:9px;border:1.5px solid var(--line);border-radius:9px">
      <option value="">Semua Petugas</option>
      <?php foreach ($petugas as $p): ?><option value="<?= $p['id'] ?>" <?= $f['user_id']==$p['id']?'selected':'' ?>><?= e($p['name']) ?></option><?php endforeach; ?>
    </select>
    <?php endif; ?>
    <select name="status" style="padding:9px;border:1.5px solid var(--line);border-radius:9px">
      <option value="">Semua Status</option>
      <?php foreach ($statusLabel as $k=>$v): ?><option value="<?= $k ?>" <?= $f['status']===$k?'selected':'' ?>><?= e($v) ?></option><?php endforeach; ?>
    </select>
    <button class="btn btn-primary" style="width:auto">Filter</button>
  </form>

  <div style="overflow-x:auto">
    <table class="tbl">
      <thead><tr><th>Tanggal</th><th>Jam</th><th>ATM</th><th>Petugas</th><th>Status</th><th>Catatan</th><th>GPS</th><th>Foto</th></tr></thead>
      <tbody>
        <?php if (!$rows): ?><tr><td colspan="8" style="text-align:center;color:var(--muted);padding:24px">Tidak ada laporan.</td></tr><?php endif; ?>
        <?php foreach ($rows as $r): ?>
          <tr>
            <td><?= e(tgl_id($r['report_date'])) ?></td>
            <td><?= e(substr($r['visit_time'],0,5)) ?> WITA</td>
            <td><b><?= e($r['atm_code']) ?></b><br><small style="color:var(--muted)"><?= e($r['atm_name']) ?></small></td>
            <td><?= e($r['petugas_name']) ?></td>
            <td><?= statusPill($r['status'],$statusLabel) ?></td>
            <td style="max-width:200px;font-size:13px"><?= e($r['note']) ?></td>
            <td style="font-size:12px;color:var(--muted)">
              <?php if(isset($r['gps_lat']) && $r['gps_lat']!=='' && $r['gps_lat']!==null): ?>
                <a href="https://www.google.com/maps?q=<?= e($r['gps_lat']) ?>,<?= e($r['gps_lng']) ?>" target="_blank" title="Buka di Google Maps" style="color:var(--blue-700);font-weight:600">
                  <?= e($r['gps_lat']) ?>,<br><?= e($r['gps_lng']) ?> 📍
                </a>
                <?php
                  $flag = isset($r['location_flag'])?$r['location_flag']:null;
                  $dist = isset($r['gps_distance'])?$r['gps_distance']:null;
                  if ($flag==='ok'): ?>
                    <br><span style="background:#e8f7ef;color:#13703f;padding:1px 7px;border-radius:99px;font-size:11px;font-weight:600">✓ <?= $dist!==null?round($dist).' m':'sesuai' ?></span>
                  <?php elseif ($flag==='jauh'): ?>
                    <br><span style="background:#fdecea;color:#a32219;padding:1px 7px;border-radius:99px;font-size:11px;font-weight:600" title="Lokasi petugas jauh dari ATM">⚠ <?= $dist!==null?round($dist).' m':'jauh' ?></span>
                  <?php endif; ?>
              <?php else: ?>-<?php endif; ?>
            </td>
            <td style="white-space:nowrap">
              <?php if($r['photo_before']): ?><a href="<?= url($r['photo_before']) ?>" target="_blank"><img src="<?= url($r['photo_before']) ?>" class="thumb" title="Sebelum"></a><?php endif; ?>
              <?php if($r['photo_after']): ?><a href="<?= url($r['photo_after']) ?>" target="_blank"><img src="<?= url($r['photo_after']) ?>" class="thumb" title="Sesudah"></a><?php endif; ?>
              <?php if(!empty($r['photo_temuan'])): ?><a href="<?= url($r['photo_temuan']) ?>" target="_blank"><img src="<?= url($r['photo_temuan']) ?>" class="thumb" style="border-color:var(--danger);border-width:2px" title="Temuan"></a><?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<style>
  .tbl{width:100%;border-collapse:collapse;font-size:13.5px}
  .tbl th{text-align:left;background:#f4f7fb;color:#46546a;padding:10px;border-bottom:2px solid var(--line);font-size:12px;text-transform:uppercase}
  .tbl td{padding:10px;border-bottom:1px solid #eef2f7;vertical-align:top}
  .thumb{width:44px;height:44px;object-fit:cover;border-radius:7px;border:1px solid var(--line);display:inline-block;margin:1px}
</style>
