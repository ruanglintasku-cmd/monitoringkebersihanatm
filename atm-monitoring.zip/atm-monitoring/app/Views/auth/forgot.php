<?php /** app/Views/auth/forgot.php */ ?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Lupa Password — Monitoring ATM Region IX</title>
<link rel="stylesheet" href="<?= asset('css/app.css') ?>">
</head>
<body>
<div class="auth-wrap">
  <aside class="auth-hero">
    <div class="brand"><div class="logo">A</div></div>
    <div class="hero-body">
      <h1>Pemulihan Akses Akun</h1>
      <p>Masukkan email terdaftar Anda. Kami akan mengirimkan instruksi untuk mengatur ulang password.</p>
    </div>
    <div class="hero-foot">© <?= date('Y') ?> Region IX Kalimantan</div>
  </aside>
  <main class="auth-panel">
    <div class="auth-card">
      <div class="eyebrow">Reset Password</div>
      <h2>Lupa Password</h2>
      <p class="sub">Tautan reset akan dikirim ke email Anda.</p>

      <?php if (!empty($success)): ?><div class="alert alert-ok"><?= e($success) ?></div><?php endif; ?>
      <?php if (!empty($error)): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>

      <form method="post" action="<?= url('forgot') ?>">
        <?= csrf_field() ?>
        <div class="field">
          <label for="email">Email Terdaftar</label>
          <div class="control"><input type="email" id="email" name="email" placeholder="nama@perusahaan.com" required></div>
        </div>
        <button type="submit" class="btn btn-primary">Kirim Tautan Reset</button>
      </form>
      <div class="auth-foot"><a href="<?= url('login') ?>">← Kembali ke halaman login</a></div>
    </div>
  </main>
</div>
</body>
</html>
