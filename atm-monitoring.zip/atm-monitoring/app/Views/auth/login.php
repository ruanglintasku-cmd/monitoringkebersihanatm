<?php /** app/Views/auth/login.php */ ?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login — Monitoring Kebersihan ATM Region IX</title>
<link rel="stylesheet" href="<?= asset('css/app.css') ?>">
</head>
<body>
<div class="auth-wrap">
  <!-- Hero -->
  <aside class="auth-hero">
    <div class="brand">
      <div class="logo">A</div>
    </div>
    <div class="hero-body">
      <h1>Monitoring Kebersihan ATM Region IX Kalimantan</h1>
      <p>Pantau aktivitas kebersihan, lokasi petugas, dan progres harian seluruh ATM secara real-time dalam satu sistem terpadu.</p>
      <div class="hero-stats">
        <div><b>24/7</b><span>Monitoring</span></div>
        <div><b>GPS</b><span>Real-time</span></div>
        <div><b>Multi</b><span>Role Access</span></div>
      </div>
    </div>
    <div class="hero-foot">© <?= date('Y') ?> Region IX Kalimantan · Internal Operational System</div>
  </aside>

  <!-- Form -->
  <main class="auth-panel">
    <div class="auth-card">
      <div class="eyebrow">Sistem Internal</div>
      <h2>Masuk ke Dashboard</h2>
      <p class="sub">Gunakan akun yang diberikan administrator.</p>

      <?php if (!empty($error)): ?>
        <div class="alert alert-error"><?= e($error) ?></div>
      <?php endif; ?>
      <?php if (!empty($success)): ?>
        <div class="alert alert-ok"><?= e($success) ?></div>
      <?php endif; ?>

      <form method="post" action="<?= url('login') ?>" autocomplete="off">
        <?= csrf_field() ?>
        <div class="field">
          <label for="username">Username</label>
          <div class="control">
            <input type="text" id="username" name="username" placeholder="cth: admin" required autofocus>
          </div>
        </div>
        <div class="field">
          <label for="password">Password</label>
          <div class="control">
            <input type="password" id="password" name="password" placeholder="Masukkan password" required>
            <button type="button" class="toggle" id="togglePw">LIHAT</button>
          </div>
        </div>
        <div class="row-between">
          <label class="check"><input type="checkbox" name="remember" value="1"> Ingat saya</label>
          <a href="<?= url('forgot') ?>">Lupa password?</a>
        </div>
        <button type="submit" class="btn btn-primary">Masuk</button>
      </form>

      <div class="demo-hint">
        <b>Akun demo</b> (password <code>password123</code>):
        admin · supervisor · adi · siti
      </div>
      <div class="auth-foot">Dilindungi otentikasi & enkripsi. Jangan bagikan kredensial Anda.</div>
    </div>
  </main>
</div>

<script>
  document.getElementById('togglePw').addEventListener('click', function(){
    var pw = document.getElementById('password');
    var show = pw.type === 'password';
    pw.type = show ? 'text' : 'password';
    this.textContent = show ? 'SEMBUNYI' : 'LIHAT';
  });
</script>
</body>
</html>
