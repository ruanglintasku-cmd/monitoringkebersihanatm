<?php
namespace App\Models;

use App\Core\Database;

class Report
{
    public static function create($d) {
        return Database::insert(
            "INSERT INTO cleaning_reports
               (atm_id,user_id,report_date,visit_time,status,note,gps_lat,gps_lng,gps_accuracy,gps_timestamp,gps_distance,location_flag)
             VALUES (:atm,:uid,:date,:time,:status,:note,:lat,:lng,:acc,:ts,:dist,:flag)",
            array(':atm'=>$d['atm_id'],':uid'=>$d['user_id'],':date'=>$d['report_date'],
             ':time'=>$d['visit_time'],':status'=>$d['status'],':note'=>$d['note'],
             ':lat'=>$d['gps_lat']?$d['gps_lat']:null,':lng'=>$d['gps_lng']?$d['gps_lng']:null,
             ':acc'=>$d['gps_accuracy']?$d['gps_accuracy']:null,':ts'=>$d['gps_timestamp']?$d['gps_timestamp']:null,
             ':dist'=>isset($d['gps_distance'])?$d['gps_distance']:null,
             ':flag'=>isset($d['location_flag'])?$d['location_flag']:null));
    }

    public static function addPhoto($reportId, $type, $path, $size, $wm) {
        Database::insert(
            "INSERT INTO report_photos (report_id,type,file_path,file_size,watermark_text)
             VALUES (:r,:t,:p,:s,:w)",
            array(':r'=>$reportId,':t'=>$type,':p'=>$path,':s'=>$size,':w'=>$wm));
    }

    public static function search($f) {
        $w = array("1=1"); $p = array();
        if (!empty($f['date_from'])) { $w[]="r.report_date>=:df"; $p[':df']=$f['date_from']; }
        if (!empty($f['date_to']))   { $w[]="r.report_date<=:dt"; $p[':dt']=$f['date_to']; }
        if (!empty($f['user_id']))   { $w[]="r.user_id=:u"; $p[':u']=$f['user_id']; }
        if (!empty($f['atm_id']))    { $w[]="r.atm_id=:a"; $p[':a']=$f['atm_id']; }
        if (!empty($f['city_id']))   { $w[]="a.city_id=:c"; $p[':c']=$f['city_id']; }
        if (!empty($f['region_id'])) { $w[]="a.region_id=:rg"; $p[':rg']=$f['region_id']; }
        if (!empty($f['status']))    { $w[]="r.status=:s"; $p[':s']=$f['status']; }
        $where = "WHERE ".implode(' AND ',$w);
        return Database::all(
            "SELECT r.*, a.code AS atm_code, a.name AS atm_name, a.address,
                    u.name AS petugas_name,
                    (SELECT file_path FROM report_photos WHERE report_id=r.id AND type='before' LIMIT 1) AS photo_before,
                    (SELECT file_path FROM report_photos WHERE report_id=r.id AND type='after'  LIMIT 1) AS photo_after,
                    (SELECT file_path FROM report_photos WHERE report_id=r.id AND type='temuan' LIMIT 1) AS photo_temuan
               FROM cleaning_reports r
               JOIN atm_locations a ON a.id=r.atm_id
               JOIN users u ON u.id=r.user_id
             $where ORDER BY r.report_date DESC, r.visit_time DESC", $p);
    }

    public static function historyForAtm($atmId) {
        return Database::all(
            "SELECT r.*, u.name AS petugas_name,
                    (SELECT file_path FROM report_photos WHERE report_id=r.id AND type='before' LIMIT 1) AS photo_before,
                    (SELECT file_path FROM report_photos WHERE report_id=r.id AND type='after'  LIMIT 1) AS photo_after
               FROM cleaning_reports r JOIN users u ON u.id=r.user_id
             WHERE r.atm_id=:a ORDER BY r.report_date DESC, r.visit_time DESC", array(':a'=>$atmId));
    }

    public static function historyForUser($userId) {
        return Database::all(
            "SELECT r.*, a.code AS atm_code, a.name AS atm_name
               FROM cleaning_reports r JOIN atm_locations a ON a.id=r.atm_id
             WHERE r.user_id=:u ORDER BY r.report_date DESC, r.visit_time DESC LIMIT 100",
            array(':u'=>$userId));
    }

    public static function reportedToday($atmId, $userId) {
        return (int)Database::scalar(
            "SELECT COUNT(*) FROM cleaning_reports
             WHERE atm_id=:a AND user_id=:u AND report_date=CURDATE()",
            array(':a'=>$atmId,':u'=>$userId)) > 0;
    }

    public static function petugasPerformance($regionId) {
        $w = "WHERE u.role_id=3 AND u.is_active=1"; $p = array();
        if ($regionId) { $w.=" AND u.region_id=:r"; $p[':r']=$regionId; }
        return Database::all(
            "SELECT u.id, u.name,
                (SELECT COUNT(*) FROM atm_locations a WHERE a.assigned_to=u.id) AS total_atm,
                (SELECT COUNT(DISTINCT r.atm_id) FROM cleaning_reports r
                   WHERE r.user_id=u.id AND r.report_date=CURDATE()) AS done_today,
                (SELECT MAX(r.created_at) FROM cleaning_reports r WHERE r.user_id=u.id) AS last_active
             FROM users u $w ORDER BY u.name", $p);
    }
}
