<?php
namespace App\Models;

use App\Core\Database;

class Atm
{
    public static function paginate($f, $page = 1, $perPage = 15) {
        $fl = self::filters($f); $where = $fl[0]; $params = $fl[1];
        $page = (int)$page; if ($page < 1) $page = 1;
        $offset = ($page - 1) * $perPage;
        $rows = Database::all(
            "SELECT a.*, r.name AS region_name, c.name AS city_name, u.name AS petugas_name
               FROM atm_locations a
               LEFT JOIN regions r ON r.id=a.region_id
               LEFT JOIN cities  c ON c.id=a.city_id
               LEFT JOIN users   u ON u.id=a.assigned_to
             $where ORDER BY a.code ASC
             LIMIT $perPage OFFSET $offset", $params);
        $total = (int) Database::scalar("SELECT COUNT(*) FROM atm_locations a $where", $params);
        return array('rows'=>$rows,'total'=>$total,'page'=>$page,'perPage'=>$perPage,
                     'pages'=>max(1,(int)ceil($total/$perPage)));
    }

    public static function all($f = array()) {
        $fl = self::filters($f); $where = $fl[0]; $params = $fl[1];
        return Database::all(
            "SELECT a.*, r.name AS region_name, c.name AS city_name, u.name AS petugas_name
               FROM atm_locations a
               LEFT JOIN regions r ON r.id=a.region_id
               LEFT JOIN cities  c ON c.id=a.city_id
               LEFT JOIN users   u ON u.id=a.assigned_to
             $where ORDER BY a.code ASC", $params);
    }

    private static function filters($f) {
        $w = array("1=1"); $p = array();
        if (!empty($f['q'])) { $w[]="(a.code LIKE :q1 OR a.name LIKE :q2 OR a.address LIKE :q3)"; $p[':q1']='%'.$f['q'].'%'; $p[':q2']='%'.$f['q'].'%'; $p[':q3']='%'.$f['q'].'%'; }
        if (!empty($f['region_id'])) { $w[]="a.region_id=:rid"; $p[':rid']=$f['region_id']; }
        if (!empty($f['city_id']))   { $w[]="a.city_id=:cid";   $p[':cid']=$f['city_id']; }
        if (!empty($f['status']))    { $w[]="a.status=:st";     $p[':st']=$f['status']; }
        if (!empty($f['assigned_to'])){ $w[]="a.assigned_to=:as"; $p[':as']=$f['assigned_to']; }
        return array('WHERE '.implode(' AND ',$w), $p);
    }

    public static function find($id) {
        return Database::one("SELECT * FROM atm_locations WHERE id=:id", array(':id'=>$id));
    }

    public static function codeExists($code, $exceptId = null) {
        $sql = "SELECT COUNT(*) FROM atm_locations WHERE code=:c"; $p = array(':c'=>$code);
        if ($exceptId) { $sql.=" AND id<>:id"; $p[':id']=$exceptId; }
        return (int)Database::scalar($sql,$p) > 0;
    }

    public static function create($d) {
        return Database::insert(
            "INSERT INTO atm_locations
               (code,name,region_id,city_id,area,address,latitude,longitude,status,daily_target,assigned_to)
             VALUES (:code,:name,:region_id,:city_id,:area,:address,:lat,:lng,:status,:target,:assigned)",
            array(':code'=>$d['code'],':name'=>$d['name'],':region_id'=>$d['region_id'],
             ':city_id'=>$d['city_id']?$d['city_id']:null,':area'=>$d['area'],':address'=>$d['address'],
             ':lat'=>$d['latitude']?$d['latitude']:null,':lng'=>$d['longitude']?$d['longitude']:null,
             ':status'=>$d['status'],':target'=>$d['daily_target'],
             ':assigned'=>$d['assigned_to']?$d['assigned_to']:null));
    }

    public static function update($id, $d) {
        Database::run(
            "UPDATE atm_locations SET code=:code,name=:name,region_id=:region_id,city_id=:city_id,
               area=:area,address=:address,latitude=:lat,longitude=:lng,status=:status,
               daily_target=:target,assigned_to=:assigned WHERE id=:id",
            array(':code'=>$d['code'],':name'=>$d['name'],':region_id'=>$d['region_id'],
             ':city_id'=>$d['city_id']?$d['city_id']:null,':area'=>$d['area'],':address'=>$d['address'],
             ':lat'=>$d['latitude']?$d['latitude']:null,':lng'=>$d['longitude']?$d['longitude']:null,
             ':status'=>$d['status'],':target'=>$d['daily_target'],
             ':assigned'=>$d['assigned_to']?$d['assigned_to']:null,':id'=>$id));
    }

    public static function delete($id) {
        Database::run("DELETE FROM atm_locations WHERE id=:id", array(':id'=>$id));
    }

    /** Insert atau update ATM lengkap dgn kolom tambahan (untuk import) */
    public static function upsertExtended($code, $d, $isUpdate) {
        $params = array(
            ':code'=>$d['code'],':name'=>$d['name'],':city_id'=>$d['city_id'],
            ':area'=>$d['area'],':address'=>$d['address'],
            ':lat'=>$d['lat'],':lng'=>$d['lng'],':status'=>$d['status'],':target'=>$d['target'],
            ':pengelola'=>$d['pengelola'],':nama_pengelola'=>$d['nama_pengelola'],
            ':sewa'=>$d['sewa'],':tipe'=>$d['tipe'],':merk'=>$d['merk'],':jenis'=>$d['jenis'],
            ':sn'=>$d['sn'],':service'=>$d['service'],':pks'=>$d['pks'],
            ':kotastat'=>$d['kotastat'],':kontak'=>$d['kontak'],':pic'=>$d['pic'],
        );
        if ($isUpdate) {
            Database::run(
                "UPDATE atm_locations SET name=:name,city_id=:city_id,area=:area,address=:address,
                   latitude=:lat,longitude=:lng,status=:status,daily_target=:target,
                   pengelola=:pengelola,nama_pengelola=:nama_pengelola,sewa_status=:sewa,
                   tipe_mesin=:tipe,merk_mesin=:merk,jenis_lokasi=:jenis,serial_number=:sn,
                   service_hours=:service,pks_status=:pks,kota_status=:kotastat,
                   kontak_vendor=:kontak,pic_slm=:pic
                 WHERE code=:code", $params);
        } else {
            $params[':region_id'] = 1;
            Database::run(
                "INSERT INTO atm_locations
                   (code,name,region_id,city_id,area,address,latitude,longitude,status,daily_target,
                    pengelola,nama_pengelola,sewa_status,tipe_mesin,merk_mesin,jenis_lokasi,
                    serial_number,service_hours,pks_status,kota_status,kontak_vendor,pic_slm)
                 VALUES (:code,:name,:region_id,:city_id,:area,:address,:lat,:lng,:status,:target,
                    :pengelola,:nama_pengelola,:sewa,:tipe,:merk,:jenis,:sn,:service,:pks,
                    :kotastat,:kontak,:pic)", $params);
        }
    }
}
