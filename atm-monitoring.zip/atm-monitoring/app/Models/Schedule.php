<?php
namespace App\Models;

use App\Core\Database;

class Schedule
{
    /** Jadwal pada tanggal tertentu (+ filter area opsional) */
    public static function forDate($date, $cityId = 0) {
        $w = "WHERE s.schedule_date=:d";
        $p = array(':d'=>$date);
        if ($cityId) { $w .= " AND a.city_id=:c"; $p[':c']=$cityId; }
        return Database::all(
            "SELECT s.*, a.code atm_code, a.name atm_name, c.name area_name, u.name petugas_name,
                    (SELECT COUNT(*) FROM cleaning_reports cr
                      WHERE cr.atm_id=s.atm_id AND cr.report_date=s.schedule_date) AS done
             FROM schedules s
             JOIN atm_locations a ON a.id=s.atm_id
             LEFT JOIN cities c ON c.id=a.city_id
             JOIN users u ON u.id=s.user_id
             $w ORDER BY c.name, a.code", $p);
    }

    public static function create($atmId, $userId, $date, $shift, $note, $by) {
        return Database::run(
            "INSERT INTO schedules (atm_id,user_id,schedule_date,shift,note,created_by)
             VALUES (:a,:u,:d,:sh,:n,:by)
             ON DUPLICATE KEY UPDATE user_id=:u2, shift=:sh2, note=:n2",
            array(':a'=>$atmId,':u'=>$userId,':d'=>$date,':sh'=>$shift?:null,':n'=>$note?:null,':by'=>$by,
                  ':u2'=>$userId,':sh2'=>$shift?:null,':n2'=>$note?:null));
    }

    public static function delete($id) {
        Database::run("DELETE FROM schedules WHERE id=:id", array(':id'=>$id));
    }

    public static function deleteForDate($date) {
        Database::run("DELETE FROM schedules WHERE schedule_date=:d", array(':d'=>$date));
    }

    /**
     * Auto-generate jadwal untuk tanggal tertentu dengan ROTASI.
     * Membagi seluruh ATM aktif ke petugas secara bergiliran.
     * $offset menggeser rotasi (mis. berdasarkan hari) agar tidak selalu sama.
     */
    public static function autoRotate($date, $by, $cityId = 0) {
        // ambil ATM aktif
        $wa = "WHERE a.status='aktif'"; $pa = array();
        if ($cityId) { $wa .= " AND a.city_id=:c"; $pa[':c']=$cityId; }
        $atms = Database::all("SELECT a.id, a.city_id FROM atm_locations a $wa ORDER BY a.city_id, a.code", $pa);

        // ambil petugas aktif
        $petugas = Database::all("SELECT id FROM users WHERE role_id=3 AND is_active=1 ORDER BY id");
        if (!$petugas || !$atms) return 0;

        $np = count($petugas);
        // offset rotasi berdasarkan selisih hari dari epoch agar tiap hari bergeser
        $offset = (int)floor(strtotime($date)/86400) % $np;

        $count = 0; $i = 0;
        foreach ($atms as $a) {
            $pidx = ($i + $offset) % $np;
            $uid = $petugas[$pidx]['id'];
            self::create($a['id'], $uid, $date, null, 'Auto-rotasi', $by);
            $count++; $i++;
        }
        return $count;
    }

    public static function mySchedule($userId, $date) {
        return Database::all(
            "SELECT s.*, a.code atm_code, a.name atm_name, a.address, a.latitude, a.longitude,
                    (SELECT COUNT(*) FROM cleaning_reports cr
                      WHERE cr.atm_id=s.atm_id AND cr.report_date=s.schedule_date) AS done
             FROM schedules s JOIN atm_locations a ON a.id=s.atm_id
             WHERE s.user_id=:u AND s.schedule_date=:d ORDER BY a.code",
            array(':u'=>$userId,':d'=>$date));
    }
}
