<?php
namespace App\Models;

use App\Core\Database;

class Ref
{
    public static function regions() { return Database::all("SELECT * FROM regions ORDER BY name"); }
    public static function cities()  { return Database::all("SELECT * FROM cities ORDER BY name"); }
    public static function petugas() {
        return Database::all("SELECT id,name FROM users WHERE role_id=3 AND is_active=1 ORDER BY name");
    }
}
