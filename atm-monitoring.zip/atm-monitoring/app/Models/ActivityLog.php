<?php
namespace App\Models;

use App\Core\Database;

class ActivityLog
{
    public static function record($action, $entity = null, $entityId = null, $description = null) {
        $uid = auth() ? auth()['id'] : null;
        Database::insert(
            "INSERT INTO activity_logs
               (user_id, action, entity, entity_id, description, ip_address, user_agent)
             VALUES (:uid, :act, :ent, :eid, :desc, :ip, :ua)",
            array(
                ':uid'  => $uid,
                ':act'  => $action,
                ':ent'  => $entity,
                ':eid'  => $entityId !== null ? (string)$entityId : null,
                ':desc' => $description,
                ':ip'   => isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : null,
                ':ua'   => isset($_SERVER['HTTP_USER_AGENT']) ? substr($_SERVER['HTTP_USER_AGENT'],0,255) : '',
            )
        );
    }
}
