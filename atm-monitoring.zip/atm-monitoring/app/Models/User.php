<?php
namespace App\Models;

use App\Core\Database;

class User
{
    public static function findByUsername($username) {
        return Database::one(
            "SELECT u.*, r.name AS role FROM users u
               JOIN roles r ON r.id = u.role_id
              WHERE u.username = :u AND u.is_active = 1 LIMIT 1",
            array(':u' => $username));
    }
    public static function findById($id) {
        return Database::one(
            "SELECT u.*, r.name AS role FROM users u JOIN roles r ON r.id=u.role_id
              WHERE u.id = :id LIMIT 1", array(':id' => $id));
    }
    public static function findByEmail($email) {
        return Database::one(
            "SELECT * FROM users WHERE email = :e AND is_active = 1 LIMIT 1", array(':e' => $email));
    }
    public static function touchLastLogin($id) {
        Database::run("UPDATE users SET last_login_at = NOW() WHERE id = :id", array(':id' => $id));
    }
    public static function setRememberToken($id, $token) {
        Database::run("UPDATE users SET remember_token = :t WHERE id = :id",
            array(':t' => $token, ':id' => $id));
    }
    public static function findByRememberToken($token) {
        return Database::one(
            "SELECT u.*, r.name AS role FROM users u JOIN roles r ON r.id=u.role_id
              WHERE u.remember_token = :t AND u.is_active = 1 LIMIT 1", array(':t' => $token));
    }
    public static function setResetToken($id, $token, $expires) {
        Database::run("UPDATE users SET reset_token = :t, reset_expires = :e WHERE id = :id",
            array(':t' => $token, ':e' => $expires, ':id' => $id));
    }
    public static function updatePassword($id, $hash) {
        Database::run("UPDATE users SET password = :p, reset_token = NULL, reset_expires = NULL WHERE id = :id",
            array(':p' => $hash, ':id' => $id));
    }
}
