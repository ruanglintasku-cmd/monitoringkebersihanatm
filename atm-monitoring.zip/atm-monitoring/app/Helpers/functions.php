<?php
/**
 * app/Helpers/functions.php — fungsi bantu global (kompatibel PHP 5.6)
 */

/** Polyfill str_starts_with (PHP < 8) */
if (!function_exists('str_starts_with')) {
    function str_starts_with($haystack, $needle) {
        return $needle === '' || strpos($haystack, $needle) === 0;
    }
}

/** Escape output (XSS protection) */
function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function url($path = '') {
    return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
}
function asset($path) {
    return url('assets/' . ltrim($path, '/'));
}
function redirect($path) {
    header('Location: ' . (str_starts_with($path, 'http') ? $path : url($path)));
    exit;
}
function view($__template, $__data = array()) {
    extract($__data, EXTR_OVERWRITE);
    $__viewFile = VIEW_PATH . '/' . str_replace('.', '/', $__template) . '.php';
    if (!is_file($__viewFile)) {
        http_response_code(500);
        die("View tidak ditemukan: " . $__template);
    }
    require $__viewFile;
}

/** ---- CSRF ---- */
function csrf_token() {
    if (empty($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(openssl_random_pseudo_bytes(32));
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}
function csrf_field() {
    return '<input type="hidden" name="' . CSRF_TOKEN_NAME . '" value="' . csrf_token() . '">';
}
function csrf_verify() {
    $token = isset($_POST[CSRF_TOKEN_NAME]) ? $_POST[CSRF_TOKEN_NAME]
           : (isset($_SERVER['HTTP_X_CSRF_TOKEN']) ? $_SERVER['HTTP_X_CSRF_TOKEN'] : '');
    $sess = isset($_SESSION[CSRF_TOKEN_NAME]) ? $_SESSION[CSRF_TOKEN_NAME] : '';
    return is_string($token) && hash_equals($sess, $token);
}

/** ---- Auth helpers ---- */
function auth() {
    return isset($_SESSION['user']) ? $_SESSION['user'] : null;
}
function is_logged_in() {
    return isset($_SESSION['user']);
}
function user_role() {
    return isset($_SESSION['user']['role']) ? $_SESSION['user']['role'] : null;
}
function old($key, $default = '') {
    return isset($_SESSION['_old'][$key]) ? $_SESSION['_old'][$key] : $default;
}

/** Flash message */
function flash($key, $msg = null) {
    if ($msg === null) {
        $val = isset($_SESSION['_flash'][$key]) ? $_SESSION['_flash'][$key] : null;
        unset($_SESSION['_flash'][$key]);
        return $val;
    }
    $_SESSION['_flash'][$key] = $msg;
}

/** Format tanggal Indonesia + WITA */
function tgl_id($datetime, $withTime = false) {
    if (!$datetime) return '-';
    $ts = is_numeric($datetime) ? $datetime : strtotime($datetime);
    $bulan = array(1=>'Januari','Februari','Maret','April','Mei','Juni',
                   'Juli','Agustus','September','Oktober','November','Desember');
    $out = date('d', $ts) . ' ' . $bulan[(int)date('n', $ts)] . ' ' . date('Y', $ts);
    if ($withTime) $out .= ', ' . date('H:i', $ts) . ' WITA';
    return $out;
}
