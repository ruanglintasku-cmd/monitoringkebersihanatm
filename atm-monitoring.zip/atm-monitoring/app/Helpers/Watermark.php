<?php
namespace App\Helpers;

class Watermark
{
    public static function apply($srcPath, $destPath, $lines) {
        $info = @getimagesize($srcPath);
        if (!$info) return false;

        switch ($info[2]) {
            case IMAGETYPE_JPEG: $img = @imagecreatefromjpeg($srcPath); break;
            case IMAGETYPE_PNG:  $img = @imagecreatefrompng($srcPath);  break;
            case IMAGETYPE_GIF:  $img = @imagecreatefromgif($srcPath);  break;
            case IMAGETYPE_WEBP: $img = function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($srcPath) : false; break;
            default: return false;
        }
        if (!$img) return false;

        $w = imagesx($img); $h = imagesy($img);
        imagealphablending($img, true);

        $fontSize = max(12, (int)round($w / 45));
        $pad      = (int)round($fontSize * 0.6);
        $lineH    = $fontSize + 6;
        $boxH     = $lineH * count($lines) + $pad * 2;
        $boxY     = $h - $boxH;

        $overlay = imagecolorallocatealpha($img, 0, 0, 0, 55);
        imagefilledrectangle($img, 0, $boxY, $w, $h, $overlay);

        $white  = imagecolorallocate($img, 255, 255, 255);
        $shadow = imagecolorallocatealpha($img, 0, 0, 0, 40);

        $ttf = self::findFont();
        $y = $boxY + $pad + $fontSize;
        $i = 0;
        foreach ($lines as $text) {
            $bold = ($i === 0);
            $fs = $bold ? $fontSize + 2 : $fontSize;
            if ($ttf) {
                imagettftext($img, $fs, 0, $pad+1, $y+1, $shadow, $ttf, $text);
                imagettftext($img, $fs, 0, $pad,   $y,   $white,  $ttf, $text);
            } else {
                imagestring($img, 5, $pad, $y - $fontSize, $text, $white);
            }
            $y += $lineH; $i++;
        }

        if (!is_dir(dirname($destPath))) @mkdir(dirname($destPath), 0775, true);
        $ok = imagejpeg($img, $destPath, 88);
        imagedestroy($img);
        return $ok;
    }

    private static function findFont() {
        $candidates = array(
            ROOT_PATH . '/public/assets/fonts/DejaVuSans.ttf',
            'C:/Windows/Fonts/arial.ttf',
            'C:/Windows/Fonts/segoeui.ttf',
            '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
        );
        foreach ($candidates as $f) if (is_file($f)) return $f;
        return null;
    }
}
