<?php
namespace App\Helpers;

class Geo
{
    /** Jarak Haversine dalam METER antara dua koordinat. */
    public static function distanceMeters($lat1, $lng1, $lat2, $lng2) {
        if ($lat1===null || $lng1===null || $lat2===null || $lng2===null) return null;
        $lat1=(float)$lat1; $lng1=(float)$lng1; $lat2=(float)$lat2; $lng2=(float)$lng2;
        if ($lat1==0 && $lng1==0) return null;
        $R = 6371000; // radius bumi meter
        $dLat = deg2rad($lat2-$lat1);
        $dLng = deg2rad($lng2-$lng1);
        $a = sin($dLat/2)*sin($dLat/2) +
             cos(deg2rad($lat1))*cos(deg2rad($lat2))*sin($dLng/2)*sin($dLng/2);
        $c = 2*atan2(sqrt($a), sqrt(1-$a));
        return round($R*$c, 1);
    }

    /** Batas radius wajar (meter) untuk menganggap petugas benar di lokasi. */
    public static function threshold() { return 50; }
}
