<?php
namespace App\Helpers;

class Exporter
{
    public static function excel($filename, $headers, $rows) {
        header('Content-Type: application/vnd.ms-excel; charset=utf-8');
        header("Content-Disposition: attachment; filename=\"{$filename}.xls\"");
        header('Cache-Control: max-age=0');
        echo "\xEF\xBB\xBF";
        echo '<table border="1"><thead><tr>';
        foreach ($headers as $h) echo '<th style="background:#0061c2;color:#fff">'.e($h).'</th>';
        echo '</tr></thead><tbody>';
        foreach ($rows as $r) {
            echo '<tr>';
            foreach ($r as $cell) echo '<td>'.e($cell).'</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
        exit;
    }

    public static function pdf($title, $headers, $rows, $subtitle = '') {
        header('Content-Type: text/html; charset=utf-8');
        $now = tgl_id(date('Y-m-d H:i:s'), true);
        echo '<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><title>'.e($title).'</title>';
        echo '<style>
          *{font-family:Segoe UI,Arial,sans-serif}
          body{margin:24px;color:#1c2430}
          .head{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #0061c2;padding-bottom:10px}
          h1{font-size:18px;margin:0;color:#003d79}.sub{color:#647082;font-size:12px;margin-top:4px}
          table{width:100%;border-collapse:collapse;margin-top:16px;font-size:11px}
          th{background:#0061c2;color:#fff;text-align:left;padding:7px 8px}
          td{border:1px solid #dde3ec;padding:6px 8px}
          tr:nth-child(even) td{background:#f6f9fd}
          .foot{margin-top:20px;font-size:10px;color:#94a0b3}
          @media print{.noprint{display:none}}
        </style></head><body onload="window.print()">';
        echo '<div class="head"><div><h1>'.e($title).'</h1><div class="sub">'.e($subtitle).'</div></div>';
        echo '<div style="text-align:right;font-size:11px;color:#647082">Region IX Kalimantan<br>Dicetak: '.e($now).'</div></div>';
        echo '<table><thead><tr>';
        foreach ($headers as $h) echo '<th>'.e($h).'</th>';
        echo '</tr></thead><tbody>';
        foreach ($rows as $r) { echo '<tr>'; foreach ($r as $c) echo '<td>'.e($c).'</td>'; echo '</tr>'; }
        echo '</tbody></table>';
        echo '<div class="foot">Dokumen ini dihasilkan otomatis oleh Sistem Monitoring Kebersihan ATM.</div>';
        echo '<div class="noprint" style="margin-top:16px"><button onclick="window.print()">Cetak / Simpan PDF</button></div>';
        echo '</body></html>';
        exit;
    }
}
