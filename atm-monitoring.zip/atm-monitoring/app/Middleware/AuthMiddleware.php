<?php
namespace App\Middleware;

class AuthMiddleware
{
    public function handle() {
        if (!is_logged_in()) {
            flash('error', 'Silakan login terlebih dahulu.');
            redirect('login');
        }
    }
}
