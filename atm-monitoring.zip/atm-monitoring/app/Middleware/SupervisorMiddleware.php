<?php
namespace App\Middleware;

class SupervisorMiddleware
{
    public function handle() {
        if (!is_logged_in()) { redirect('login'); }
        if (user_role() !== 'supervisor') {
            http_response_code(403);
            die('403 — Akses ditolak untuk role Anda.');
        }
    }
}
