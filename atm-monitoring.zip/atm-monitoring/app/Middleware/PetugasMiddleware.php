<?php
namespace App\Middleware;

class PetugasMiddleware
{
    public function handle() {
        if (!is_logged_in()) { redirect('login'); }
        if (user_role() !== 'petugas') {
            http_response_code(403);
            die('403 — Akses ditolak untuk role Anda.');
        }
    }
}
