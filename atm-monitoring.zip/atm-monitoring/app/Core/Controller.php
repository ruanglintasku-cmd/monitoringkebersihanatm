<?php
namespace App\Core;

abstract class Controller
{
    protected function view($template, $data = array()) {
        view($template, $data);
    }

    protected function json($data, $code = 200) {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }

    protected function requireCsrf() {
        if (!csrf_verify()) {
            http_response_code(419);
            die('419 — Token CSRF tidak valid. Muat ulang halaman.');
        }
    }

    protected function input($key, $default = '') {
        $v = isset($_POST[$key]) ? $_POST[$key] : $default;
        return is_string($v) ? trim($v) : $v;
    }
}
