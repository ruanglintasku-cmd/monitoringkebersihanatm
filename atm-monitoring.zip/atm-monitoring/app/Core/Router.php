<?php
namespace App\Core;

class Router
{
    private $routes = array('GET' => array(), 'POST' => array());

    public function get($path, $handler, $middleware = array()) {
        $this->routes['GET'][$this->norm($path)] = array('handler'=>$handler,'middleware'=>$middleware);
    }
    public function post($path, $handler, $middleware = array()) {
        $this->routes['POST'][$this->norm($path)] = array('handler'=>$handler,'middleware'=>$middleware);
    }

    private function norm($path) {
        return '/' . trim($path, '/');
    }

    private function currentUri() {
        $reqUri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/';
        $uri = parse_url($reqUri, PHP_URL_PATH);
        if (!$uri) $uri = '/';
        $uri = '/' . trim(rawurldecode($uri), '/');

        $base = rtrim((string)parse_url(BASE_URL, PHP_URL_PATH), '/');
        if ($base !== '' && ($uri === $base || str_starts_with($uri . '/', $base . '/'))) {
            $uri = '/' . trim(substr($uri, strlen($base)), '/');
        }
        if (str_starts_with($uri, '/index.php')) {
            $uri = '/' . ltrim(substr($uri, strlen('/index.php')), '/');
        }
        if (str_starts_with($uri . '/', '/public/')) {
            $uri = '/' . trim(substr($uri, strlen('/public')), '/');
        }
        return $uri === '' ? '/' : $uri;
    }

    public function dispatch() {
        $method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET';
        $uri    = $this->currentUri();
        $route  = isset($this->routes[$method][$uri]) ? $this->routes[$method][$uri] : null;

        if (!$route) {
            http_response_code(404);
            echo '404 — Halaman tidak ditemukan';
            return;
        }

        foreach ($route['middleware'] as $mw) {
            $class = "App\\Middleware\\" . $mw;
            $obj = new $class();
            $obj->handle();
        }

        $handler = $route['handler'];
        if (is_array($handler)) {
            $class = $handler[0]; $action = $handler[1];
            $obj = new $class();
            $obj->$action();
        } else {
            call_user_func($handler);
        }
    }
}
