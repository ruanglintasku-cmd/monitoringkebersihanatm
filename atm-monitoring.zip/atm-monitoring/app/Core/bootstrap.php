<?php
/**
 * app/Core/bootstrap.php — inisialisasi (kompatibel PHP 5.6)
 */
require_once dirname(dirname(__DIR__)) . '/config/config.php';

spl_autoload_register(function ($class) {
    $prefix = 'App\\';
    if (strncmp($class, $prefix, strlen($prefix)) !== 0) return;
    $relative = substr($class, strlen($prefix));
    $file = APP_PATH . '/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($file)) require_once $file;
});

require_once APP_PATH . '/Helpers/functions.php';

// cookie secure otomatis bila situs HTTPS (deteksi sama seperti di config)
$__secure = (strpos(BASE_URL, 'https://') === 0);

session_name(SESSION_NAME);
if (PHP_VERSION_ID >= 70300) {
    session_set_cookie_params(array(
        'lifetime' => SESSION_LIFETIME, 'path' => '/',
        'httponly' => true, 'samesite' => 'Lax', 'secure' => $__secure,
    ));
} else {
    session_set_cookie_params(SESSION_LIFETIME, '/; samesite=Lax', '', $__secure, true);
}
session_start();
