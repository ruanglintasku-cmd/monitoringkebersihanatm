<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Atm;
use App\Models\Ref;
use App\Models\ActivityLog;
use App\Helpers\Exporter;

class AtmController extends Controller
{
    public function index() {
        $f = array(
            'q'         => isset($_GET['q']) ? trim($_GET['q']) : '',
            'region_id' => isset($_GET['region_id']) ? $_GET['region_id'] : '',
            'city_id'   => isset($_GET['city_id']) ? $_GET['city_id'] : '',
            'status'    => isset($_GET['status']) ? $_GET['status'] : '',
        );
        $page = isset($_GET['page']) ? max(1,(int)$_GET['page']) : 1;
        $data = Atm::paginate($f, $page);

        ob_start();
        view('admin.atm_index', array(
            'data'=>$data,'f'=>$f,
            'regions'=>Ref::regions(),'cities'=>Ref::cities(),'petugas'=>Ref::petugas(),
            'success'=>flash('success'),'error'=>flash('error'),
        ));
        $content = ob_get_clean();
        view('layouts.app', array('title'=>'Kelola Data ATM','active'=>'atm','content'=>$content,'notifCount'=>0));
    }

    public function store() {
        $this->requireCsrf();
        $d = $this->collect();
        $err = $this->validate($d);
        if ($err) { flash('error',$err); redirect('admin/atm'); }
        if (Atm::codeExists($d['code'])) { flash('error','Kode ATM sudah digunakan.'); redirect('admin/atm'); }
        $id = Atm::create($d);
        ActivityLog::record('create_atm','atm_locations',$id,"Tambah ATM ".$d['code']);
        flash('success','ATM berhasil ditambahkan.');
        redirect('admin/atm');
    }

    public function update() {
        $this->requireCsrf();
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        $d = $this->collect();
        $err = $this->validate($d);
        if ($err) { flash('error',$err); redirect('admin/atm'); }
        if (Atm::codeExists($d['code'],$id)) { flash('error','Kode ATM sudah digunakan.'); redirect('admin/atm'); }
        Atm::update($id,$d);
        ActivityLog::record('update_atm','atm_locations',$id,"Edit ATM ".$d['code']);
        flash('success','ATM berhasil diperbarui.');
        redirect('admin/atm');
    }

    public function delete() {
        $this->requireCsrf();
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        Atm::delete($id);
        ActivityLog::record('delete_atm','atm_locations',$id,"Hapus ATM #".$id);
        flash('success','ATM berhasil dihapus.');
        redirect('admin/atm');
    }

    public function exportExcel() {
        $rows = array();
        foreach (Atm::all() as $a) {
            $rows[] = array(
                $a['code'],$a['name'],
                isset($a['city_name'])?$a['city_name']:'',
                $a['area'],$a['address'],$a['latitude'],$a['longitude'],
                $a['status'],$a['daily_target'],
                isset($a['tipe_mesin'])?$a['tipe_mesin']:'',
                isset($a['merk_mesin'])?$a['merk_mesin']:'',
                isset($a['pengelola'])?$a['pengelola']:'',
                isset($a['nama_pengelola'])?$a['nama_pengelola']:'',
                isset($a['sewa_status'])?$a['sewa_status']:'',
                isset($a['jenis_lokasi'])?$a['jenis_lokasi']:'',
                isset($a['serial_number'])?$a['serial_number']:'',
                isset($a['service_hours'])?$a['service_hours']:'',
                isset($a['pks_status'])?$a['pks_status']:'',
                isset($a['kota_status'])?$a['kota_status']:'',
                isset($a['kontak_vendor'])?$a['kontak_vendor']:'',
                isset($a['pic_slm'])?$a['pic_slm']:'',
                isset($a['petugas_name'])?$a['petugas_name']:'',
            );
        }
        Exporter::excel('data_atm_'.date('Ymd'),
            array('Kode','Nama','Kota','Area','Alamat','Latitude','Longitude','Status','Target',
                  'Tipe Mesin','Merk Mesin','Pengelola','Nama Pengelola','Sewa/Tidak Sewa',
                  'Jenis Lokasi','SN','Service Hours','PKS Ada / Tidak Ada','Dalam/Luar Kota',
                  'Kontak Vendor','PIC SLM','Petugas'),
            $rows);
    }

    public function importExcel() {
        $this->requireCsrf();
        if (empty($_FILES['file']['tmp_name'])) { flash('error','Pilih file CSV terlebih dahulu.'); redirect('admin/atm'); }
        $fh = fopen($_FILES['file']['tmp_name'],'r');
        if (!$fh) { flash('error','Gagal membaca file.'); redirect('admin/atm'); }

        // Peta nama kota -> id
        $cityMap = array();
        foreach (\App\Models\Ref::cities() as $c) $cityMap[strtolower(trim($c['name']))] = $c['id'];

        // Baca header (baris pertama) dan petakan posisi kolom berdasarkan nama
        $header = fgetcsv($fh, 0, ',');
        if (!$header) { fclose($fh); flash('error','File kosong.'); redirect('admin/atm'); }
        $idx = array();
        foreach ($header as $i=>$h) {
            $key = strtolower(trim(str_replace(array("\xEF\xBB\xBF"), '', $h)));
            $idx[$key] = $i;
        }
        // alias kolom -> nama internal
        $alias = array(
            'code'=>array('kode','kode atm','terminal id','code'),
            'name'=>array('nama','nama atm','lokasi','name'),
            'city'=>array('kota','area','city'),
            'area'=>array('area','wilayah'),
            'address'=>array('alamat','alamat lengkap','address'),
            'lat'=>array('latitude','latitude atm','lat'),
            'lng'=>array('longitude','longitude atm','long','lng'),
            'tipe'=>array('tipe mesin','tipe','tipe_mesin'),
            'merk'=>array('merk mesin','merk','merk_mesin'),
            'pengelola'=>array('pengelola'),
            'nama_pengelola'=>array('nama pengelola','nama_pengelola'),
            'sewa'=>array('sewa/tidak sewa','sewa','status sewa'),
            'jenis'=>array('jenis lokasi','jenis_lokasi'),
            'sn'=>array('sn','serial number','serial_number'),
            'service'=>array('service hours','service_hours','jam layanan'),
            'pks'=>array('pks ada / tidak ada','pks','pks_status'),
            'kotastat'=>array('dalam/luar kota','dalam kota/luar kota','kota_status'),
            'kontak'=>array('kontak vendor','kontak_vendor'),
            'pic'=>array('pic slm','pic_slm','pic'),
            'status'=>array('status','status atm'),
            'target'=>array('target','daily_target','target kebersihan'),
        );
        $col = function($names) use ($idx) {
            foreach ($names as $n) if (isset($idx[$n])) return $idx[$n];
            return -1;
        };
        $get = function($row, $names) use ($col) {
            $i = $col($names);
            if ($i < 0 || !isset($row[$i])) return '';
            return trim($row[$i]);
        };

        $created = 0; $updated = 0; $skipped = 0;
        while (($row = fgetcsv($fh, 0, ',')) !== false) {
            $code = $get($row, $alias['code']);
            if ($code === '') { $skipped++; continue; }
            $cityName = strtolower($get($row, $alias['city']));
            // ambil hanya nama kota dari format "149 / BALIKPAPAN"
            if (strpos($cityName, '/') !== false) {
                $parts = explode('/', $cityName);
                $cityName = strtolower(trim($parts[count($parts)-1]));
            }
            $cityId = isset($cityMap[$cityName]) ? $cityMap[$cityName] : null;

            $lat = $get($row, $alias['lat']); $lat = ($lat!=='' && is_numeric(str_replace(',','.',$lat))) ? str_replace(',','.',$lat) : null;
            $lng = $get($row, $alias['lng']); $lng = ($lng!=='' && is_numeric(str_replace(',','.',$lng))) ? str_replace(',','.',$lng) : null;

            $status = strtolower($get($row, $alias['status']));
            if (!in_array($status, array('aktif','nonaktif','maintenance'), true)) $status = 'aktif';
            $target = (int)$get($row, $alias['target']); if ($target < 1) $target = 1;

            $d = array(
                'code'=>$code,
                'name'=>$get($row,$alias['name']) ?: $code,
                'city_id'=>$cityId,
                'area'=>$get($row,$alias['area']),
                'address'=>$get($row,$alias['address']),
                'lat'=>$lat,'lng'=>$lng,
                'status'=>$status,'target'=>$target,
                'pengelola'=>$get($row,$alias['pengelola']),
                'nama_pengelola'=>$get($row,$alias['nama_pengelola']),
                'sewa'=>$get($row,$alias['sewa']),
                'tipe'=>$get($row,$alias['tipe']),
                'merk'=>$get($row,$alias['merk']),
                'jenis'=>$get($row,$alias['jenis']),
                'sn'=>$get($row,$alias['sn']),
                'service'=>$get($row,$alias['service']),
                'pks'=>$get($row,$alias['pks']),
                'kotastat'=>$get($row,$alias['kotastat']),
                'kontak'=>$get($row,$alias['kontak']),
                'pic'=>$get($row,$alias['pic']),
            );

            if (Atm::codeExists($code)) {
                Atm::upsertExtended($code, $d, true);
                $updated++;
            } else {
                Atm::upsertExtended($code, $d, false);
                $created++;
            }
        }
        fclose($fh);
        ActivityLog::record('import_atm','atm_locations',null,"Import: $created baru, $updated update");
        flash('success',"Import selesai: $created ATM baru, $updated diperbarui, $skipped dilewati.");
        redirect('admin/atm');
    }

    private function collect() {
        return array(
            'code'=>$this->input('code'),'name'=>$this->input('name'),
            'region_id'=>(int)$this->input('region_id'),'city_id'=>$this->input('city_id'),
            'area'=>$this->input('area'),'address'=>$this->input('address'),
            'latitude'=>$this->input('latitude'),'longitude'=>$this->input('longitude'),
            'status'=>$this->input('status')?:'aktif','daily_target'=>(int)$this->input('daily_target')?:1,
            'assigned_to'=>$this->input('assigned_to'),
        );
    }

    private function validate($d) {
        if ($d['code']==='') return 'Kode ATM wajib diisi.';
        if ($d['name']==='') return 'Nama ATM wajib diisi.';
        if (!$d['region_id']) return 'Region wajib dipilih.';
        return null;
    }
}
