<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Models\Ref;
use App\Models\ActivityLog;

class AdminController extends Controller
{
    public function users() {
        $rows = Database::all(
            "SELECT u.*, r.label role_label, rg.name region_name
               FROM users u JOIN roles r ON r.id=u.role_id
               LEFT JOIN regions rg ON rg.id=u.region_id ORDER BY u.role_id,u.name");
        ob_start();
        view('admin.users', array('rows'=>$rows,'regions'=>Ref::regions(),
            'success'=>flash('success'),'error'=>flash('error')));
        $c = ob_get_clean();
        view('layouts.app',array('title'=>'Kelola User','active'=>'users','content'=>$c,'notifCount'=>0));
    }

    public function storeUser() {
        $this->requireCsrf();
        $username = $this->input('username');
        $name = $this->input('name');
        $roleId = (int)$this->input('role_id');
        $pass = $this->input('password');
        if ($username===''||$name===''||$pass===''||!$roleId){ flash('error','Lengkapi semua field wajib.'); redirect('admin/users'); }
        if ((int)Database::scalar("SELECT COUNT(*) FROM users WHERE username=:u",array(':u'=>$username))>0){
            flash('error','Username sudah dipakai.'); redirect('admin/users');
        }
        $id = Database::insert(
            "INSERT INTO users (role_id,region_id,nip,name,username,email,phone,password,is_active,created_by)
             VALUES (:r,:rg,:nip,:n,:u,:e,:p,:pw,1,:cb)",
            array(':r'=>$roleId,':rg'=>$this->input('region_id')?:null,':nip'=>$this->input('nip'),
             ':n'=>$name,':u'=>$username,':e'=>$this->input('email')?:null,':p'=>$this->input('phone'),
             ':pw'=>password_hash($pass,PASSWORD_BCRYPT),':cb'=>auth()['id']));
        ActivityLog::record('create_user','users',$id,"Tambah user ".$username);
        flash('success','User berhasil ditambahkan.');
        redirect('admin/users');
    }

    public function updateUser() {
        $this->requireCsrf();
        $id = (int)$this->input('id');
        if (!$id) { flash('error','User tidak valid.'); redirect('admin/users'); }
        $name = $this->input('name');
        $username = $this->input('username');
        $roleId = (int)$this->input('role_id');
        if ($name===''||$username===''||!$roleId){ flash('error','Lengkapi field wajib.'); redirect('admin/users'); }
        // cek username unik (kecuali milik sendiri)
        if ((int)Database::scalar("SELECT COUNT(*) FROM users WHERE username=:u AND id<>:id",
              array(':u'=>$username,':id'=>$id))>0){
            flash('error','Username sudah dipakai user lain.'); redirect('admin/users');
        }
        $pass = $this->input('password');
        if ($pass !== '') {
            Database::run(
                "UPDATE users SET name=:n,username=:u,role_id=:r,region_id=:rg,nip=:nip,email=:e,phone=:p,password=:pw WHERE id=:id",
                array(':n'=>$name,':u'=>$username,':r'=>$roleId,':rg'=>$this->input('region_id')?:null,
                 ':nip'=>$this->input('nip'),':e'=>$this->input('email')?:null,':p'=>$this->input('phone'),
                 ':pw'=>password_hash($pass,PASSWORD_BCRYPT),':id'=>$id));
        } else {
            Database::run(
                "UPDATE users SET name=:n,username=:u,role_id=:r,region_id=:rg,nip=:nip,email=:e,phone=:p WHERE id=:id",
                array(':n'=>$name,':u'=>$username,':r'=>$roleId,':rg'=>$this->input('region_id')?:null,
                 ':nip'=>$this->input('nip'),':e'=>$this->input('email')?:null,':p'=>$this->input('phone'),':id'=>$id));
        }
        ActivityLog::record('update_user','users',$id,"Edit user ".$username);
        flash('success','User berhasil diperbarui.');
        redirect('admin/users');
    }

    public function toggleUser() {
        $this->requireCsrf();
        $id = (int)$this->input('id');
        Database::run("UPDATE users SET is_active=1-is_active WHERE id=:id AND id<>:me",
            array(':id'=>$id,':me'=>auth()['id']));
        ActivityLog::record('toggle_user','users',$id,"Ubah status user #".$id);
        flash('success','Status user diperbarui.');
        redirect('admin/users');
    }

    public function regions() {
        // "Wilayah" sekarang = AREA (kota), mis. Banjarmasin, Pontianak, dll
        $rows = Database::all(
            "SELECT c.*, (SELECT COUNT(*) FROM atm_locations a WHERE a.city_id=c.id) atm_count
               FROM cities c ORDER BY c.name");
        ob_start();
        view('admin.regions',array('rows'=>$rows,
            'success'=>flash('success'),'error'=>flash('error')));
        $c = ob_get_clean();
        view('layouts.app',array('title'=>'Kelola Area','active'=>'regions','content'=>$c,'notifCount'=>0));
    }

    public function storeRegion() {
        $this->requireCsrf();
        $name=$this->input('name');
        if($name===''){flash('error','Nama area wajib diisi.');redirect('admin/regions');}
        $id=$this->input('id');
        if ($id) {
            Database::run("UPDATE cities SET name=:n WHERE id=:id", array(':n'=>$name,':id'=>(int)$id));
            ActivityLog::record('update_area','cities',$id,"Edit area ".$name);
            flash('success','Area diperbarui.');
        } else {
            // cek duplikat
            if ((int)Database::scalar("SELECT COUNT(*) FROM cities WHERE LOWER(name)=LOWER(:n)",array(':n'=>$name))>0){
                flash('error','Area dengan nama itu sudah ada.'); redirect('admin/regions');
            }
            $newId=Database::insert("INSERT INTO cities (region_id,name) VALUES (1,:n)", array(':n'=>$name));
            ActivityLog::record('create_area','cities',$newId,"Tambah area ".$name);
            flash('success','Area ditambahkan.');
        }
        redirect('admin/regions');
    }

    public function deleteRegion() {
        $this->requireCsrf();
        $id=(int)$this->input('id');
        $cnt=(int)Database::scalar("SELECT COUNT(*) FROM atm_locations WHERE city_id=:id",array(':id'=>$id));
        if ($cnt>0){ flash('error','Tidak bisa hapus: masih ada '.$cnt.' ATM di area ini.'); redirect('admin/regions'); }
        Database::run("DELETE FROM cities WHERE id=:id",array(':id'=>$id));
        ActivityLog::record('delete_area','cities',$id,"Hapus area #".$id);
        flash('success','Area dihapus.');
        redirect('admin/regions');
    }

    public function targets() {
        $rows = Database::all(
            "SELECT t.*, r.name region_name FROM targets t
               LEFT JOIN regions r ON r.id=t.region_id ORDER BY t.target_date DESC LIMIT 60");
        ob_start();
        view('admin.targets',array('rows'=>$rows,'regions'=>Ref::regions(),
            'success'=>flash('success'),'error'=>flash('error')));
        $c = ob_get_clean();
        view('layouts.app',array('title'=>'Target Harian','active'=>'targets','content'=>$c,'notifCount'=>0));
    }

    public function storeTarget() {
        $this->requireCsrf();
        $date=$this->input('target_date'); $count=(int)$this->input('target_count');
        $region=$this->input('region_id')?:null;
        if($date===''){flash('error','Tanggal wajib.');redirect('admin/targets');}
        Database::run(
            "INSERT INTO targets (region_id,target_date,target_count,created_by)
             VALUES (:r,:d,:c,:cb)
             ON DUPLICATE KEY UPDATE target_count=:c2",
            array(':r'=>$region,':d'=>$date,':c'=>$count,':cb'=>auth()['id'],':c2'=>$count));
        ActivityLog::record('set_target','targets',null,"Set target ".$date." = ".$count);
        flash('success','Target disimpan.'); redirect('admin/targets');
    }

    public function logs() {
        $rows = Database::all(
            "SELECT l.*, u.name user_name FROM activity_logs l
               LEFT JOIN users u ON u.id=l.user_id
             ORDER BY l.created_at DESC LIMIT 200");
        ob_start();
        view('admin.logs',array('rows'=>$rows));
        $c = ob_get_clean();
        view('layouts.app',array('title'=>'Audit Log','active'=>'logs','content'=>$c,'notifCount'=>0));
    }
}
