<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;
use App\Models\Report;
use App\Models\Ref;
use App\Helpers\Exporter;

class SupervisorController extends Controller
{
    /** Bangun WHERE + params untuk monitoring ATM (dipakai list & export) */
    private function buildAtmFilter($u, $q, $cityId) {
        $w = array("a.status='aktif'");
        $p = array();
        if ($u['region_id']) { $w[] = "a.region_id=".(int)$u['region_id']; }
        if ($q !== '') {
            // placeholder unik: nama placeholder TIDAK boleh diulang saat emulate prepares = false
            $w[] = "(a.code LIKE :q1 OR a.name LIKE :q2 OR a.address LIKE :q3)";
            $p[':q1'] = '%'.$q.'%'; $p[':q2'] = '%'.$q.'%'; $p[':q3'] = '%'.$q.'%';
        }
        if ($cityId) { $w[] = "a.city_id=:cid"; $p[':cid'] = $cityId; }
        return array("WHERE ".implode(' AND ', $w), $p);
    }

    private function fetchAtmRows($where, $p, $status) {
        $rows = Database::all(
            "SELECT a.*, c.name city_name, u.name petugas_name,
                CASE WHEN cr.id IS NULL THEN 'belum' ELSE 'sudah' END today_status,
                cr.status clean_status, cr.visit_time
             FROM atm_locations a
             LEFT JOIN cities c ON c.id=a.city_id
             LEFT JOIN users u ON u.id=a.assigned_to
             LEFT JOIN cleaning_reports cr ON cr.atm_id=a.id AND cr.report_date=CURDATE()
             $where
             ORDER BY a.code", $p);
        if ($status === 'sudah' || $status === 'belum') {
            $out = array();
            foreach ($rows as $r) if ($r['today_status'] === $status) $out[] = $r;
            return $out;
        }
        return $rows;
    }

    public function atm() {
        $u = auth();
        $q      = isset($_GET['q']) ? trim($_GET['q']) : '';
        $cityId = isset($_GET['city_id']) ? (int)$_GET['city_id'] : 0;
        $status = isset($_GET['status']) ? $_GET['status'] : '';

        $f = $this->buildAtmFilter($u, $q, $cityId);
        $rows = $this->fetchAtmRows($f[0], $f[1], $status);

        $allFiltered = $this->fetchAtmRows($f[0], $f[1], '');
        $sudah=0;$belum=0;
        foreach ($allFiltered as $r) { if($r['today_status']==='sudah')$sudah++; else $belum++; }

        $cities = Ref::cities();

        ob_start();
        view('supervisor.atm_monitor', array(
            'rows'=>$rows,'cities'=>$cities,
            'q'=>$q,'cityId'=>$cityId,'status'=>$status,
            'sudah'=>$sudah,'belum'=>$belum,'total'=>$sudah+$belum,
        ));
        $c = ob_get_clean();
        view('layouts.app',array('title'=>'Monitoring ATM','active'=>'atm','content'=>$c,'notifCount'=>$belum));
    }

    public function exportAtm() {
        $u = auth();
        $q      = isset($_GET['q']) ? trim($_GET['q']) : '';
        $cityId = isset($_GET['city_id']) ? (int)$_GET['city_id'] : 0;
        $status = isset($_GET['status']) ? $_GET['status'] : '';

        $f = $this->buildAtmFilter($u, $q, $cityId);
        $rows = $this->fetchAtmRows($f[0], $f[1], $status);

        $data = array();
        foreach ($rows as $r) {
            $data[] = array(
                $r['code'], $r['name'],
                isset($r['city_name'])?$r['city_name']:'-',
                isset($r['petugas_name'])?$r['petugas_name']:'-',
                $r['today_status']==='sudah'?'Sudah Dibersihkan':'Belum Dibersihkan',
                $r['clean_status']?ucwords(str_replace('_',' ',$r['clean_status'])):'-',
                $r['visit_time']?substr($r['visit_time'],0,5).' WITA':'-',
                isset($r['latitude'])?$r['latitude']:'',
                isset($r['longitude'])?$r['longitude']:'',
            );
        }
        Exporter::excel('monitoring_atm_'.date('Ymd'),
            array('Kode','Nama ATM','Area','Petugas','Status Hari Ini','Kebersihan','Jam Kunjungan','Latitude','Longitude'),
            $data);
    }

    public function petugas() {
        $u = auth();
        $rows = Report::petugasPerformance($u['region_id'] ? $u['region_id'] : null);
        ob_start();
        view('supervisor.petugas_monitor', array('rows'=>$rows));
        $c = ob_get_clean();
        view('layouts.app',array('title'=>'Monitoring Petugas','active'=>'petugas','content'=>$c,'notifCount'=>0));
    }

    public function map() {
        ob_start();
        view('supervisor.map');
        $c = ob_get_clean();
        view('layouts.app',array('title'=>'Peta Monitoring','active'=>'map','content'=>$c,'notifCount'=>0));
    }
}
