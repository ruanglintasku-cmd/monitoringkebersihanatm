<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Schedule;
use App\Models\Atm;
use App\Models\Ref;
use App\Models\ActivityLog;

class ScheduleController extends Controller
{
    public function index() {
        $date   = isset($_GET['date']) && $_GET['date']!=='' ? $_GET['date'] : date('Y-m-d');
        $cityId = isset($_GET['city_id']) ? (int)$_GET['city_id'] : 0;
        $rows   = Schedule::forDate($date, $cityId);
        $cities = Ref::cities();
        $petugas= Ref::petugas();
        $atms   = Atm::all($cityId ? array('city_id'=>$cityId) : array());
        ob_start();
        view('admin.schedule', array(
            'rows'=>$rows,'date'=>$date,'cityId'=>$cityId,
            'cities'=>$cities,'petugas'=>$petugas,'atms'=>$atms,
            'success'=>flash('success'),'error'=>flash('error'),
        ));
        $c = ob_get_clean();
        view('layouts.app',array('title'=>'Penjadwalan Tugas','active'=>'schedule','content'=>$c,'notifCount'=>0));
    }

    public function store() {
        $this->requireCsrf();
        $atmId  = (int)$this->input('atm_id');
        $userId = (int)$this->input('user_id');
        $date   = $this->input('schedule_date');
        $shift  = $this->input('shift');
        $note   = $this->input('note');
        if (!$atmId || !$userId || $date==='') { flash('error','ATM, petugas, dan tanggal wajib.'); redirect('admin/schedule?date='.$date); }
        Schedule::create($atmId,$userId,$date,$shift,$note,auth()['id']);
        ActivityLog::record('create_schedule','schedules',$atmId,"Jadwal $date");
        flash('success','Jadwal disimpan.');
        redirect('admin/schedule?date='.$date);
    }

    public function autoRotate() {
        $this->requireCsrf();
        $date   = $this->input('schedule_date') ?: date('Y-m-d');
        $cityId = (int)$this->input('city_id');
        $n = Schedule::autoRotate($date, auth()['id'], $cityId);
        ActivityLog::record('auto_rotate','schedules',null,"Auto rotasi $date: $n jadwal");
        flash('success',"Auto-rotasi selesai: $n ATM dijadwalkan untuk $date.");
        redirect('admin/schedule?date='.$date.($cityId?'&city_id='.$cityId:''));
    }

    public function delete() {
        $this->requireCsrf();
        $id = (int)$this->input('id');
        $date = $this->input('schedule_date') ?: date('Y-m-d');
        Schedule::delete($id);
        ActivityLog::record('delete_schedule','schedules',$id,'Hapus jadwal');
        flash('success','Jadwal dihapus.');
        redirect('admin/schedule?date='.$date);
    }

    public function clearDate() {
        $this->requireCsrf();
        $date = $this->input('schedule_date') ?: date('Y-m-d');
        Schedule::deleteForDate($date);
        ActivityLog::record('clear_schedule','schedules',null,"Hapus semua jadwal $date");
        flash('success','Semua jadwal pada tanggal itu dihapus.');
        redirect('admin/schedule?date='.$date);
    }
}
