<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\User;
use App\Models\ActivityLog;

class AuthController extends Controller
{
    public function showLogin() {
        $this->tryRememberMe();
        if (is_logged_in()) {
            redirect($this->homeFor(user_role()));
        }
        $this->view('auth.login', array(
            'title'  => 'Login',
            'error'  => flash('error'),
            'success'=> flash('success'),
        ));
    }

    public function login() {
        $this->requireCsrf();
        $username = $this->input('username');
        $password = $this->input('password');
        $remember = !empty($_POST['remember']);

        if ($username === '' || $password === '') {
            flash('error', 'Username dan password wajib diisi.');
            redirect('login');
        }

        $user = User::findByUsername($username);

        if (!$user || !password_verify($password, $user['password'])) {
            ActivityLog::record('login_failed', 'users', isset($user['id']) ? $user['id'] : null,
                "Gagal login untuk username: " . $username);
            flash('error', 'Username atau password salah.');
            redirect('login');
        }

        if (password_needs_rehash($user['password'], PASSWORD_BCRYPT)) {
            User::updatePassword((int)$user['id'], password_hash($password, PASSWORD_BCRYPT));
        }

        $this->establishSession($user);

        if ($remember) {
            $token = bin2hex(openssl_random_pseudo_bytes(32));
            User::setRememberToken((int)$user['id'], $token);
            setcookie('remember_token', $token, time() + 60*60*24*30, '/', '', false, true);
        }

        User::touchLastLogin((int)$user['id']);
        ActivityLog::record('login', 'users', $user['id'], "Login berhasil: " . $user['username']);
        redirect($this->homeFor($user['role']));
    }

    public function logout() {
        if (is_logged_in()) {
            ActivityLog::record('logout', 'users', auth()['id'], 'Logout');
            User::setRememberToken((int)auth()['id'], null);
        }
        setcookie('remember_token', '', time() - 3600, '/');
        $_SESSION = array();
        session_destroy();
        redirect('login');
    }

    public function showForgot() {
        $this->view('auth.forgot', array(
            'title'   => 'Lupa Password',
            'error'   => flash('error'),
            'success' => flash('success'),
        ));
    }

    public function sendReset() {
        $this->requireCsrf();
        $email = $this->input('email');
        $user  = $email ? User::findByEmail($email) : null;

        if ($user) {
            $token   = bin2hex(openssl_random_pseudo_bytes(32));
            $expires = date('Y-m-d H:i:s', time() + 3600);
            User::setResetToken((int)$user['id'], $token, $expires);
            ActivityLog::record('password_reset_request', 'users', $user['id'], $email);
            if (APP_ENV === 'local') {
                flash('success', 'Tautan reset (mode lokal): ' . url('reset?token=' . $token));
                redirect('forgot');
            }
        }
        flash('success', 'Jika email terdaftar, instruksi reset telah dikirim.');
        redirect('forgot');
    }

    private function establishSession($user) {
        session_regenerate_id(true);
        $_SESSION['user'] = array(
            'id'        => (int)$user['id'],
            'name'      => $user['name'],
            'username'  => $user['username'],
            'role'      => $user['role'],
            'region_id' => $user['region_id'] !== null ? (int)$user['region_id'] : null,
            'photo'     => isset($user['photo']) ? $user['photo'] : null,
        );
    }

    private function tryRememberMe() {
        if (is_logged_in()) return;
        $token = isset($_COOKIE['remember_token']) ? $_COOKIE['remember_token'] : '';
        if ($token === '') return;
        $user = User::findByRememberToken($token);
        if ($user) {
            $this->establishSession($user);
            User::touchLastLogin((int)$user['id']);
        }
    }

    private function homeFor($role) {
        return 'dashboard';
    }
}
