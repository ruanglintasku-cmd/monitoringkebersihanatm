<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Atm;
use App\Models\Report;
use App\Models\Schedule;

class PetugasController extends Controller
{
    public function atm() {
        $u = auth();
        $today = date('Y-m-d');
        // Prioritas: jadwal hari ini
        $sched = Schedule::mySchedule($u['id'], $today);
        $atms = array();
        if ($sched) {
            foreach ($sched as $s) {
                $atms[] = array(
                    'id'=>$s['atm_id'],'code'=>$s['atm_code'],'name'=>$s['atm_name'],
                    'address'=>$s['address'],'latitude'=>$s['latitude'],'longitude'=>$s['longitude'],
                    'reported'=>($s['done']>0),
                );
            }
        } else {
            $atms = Atm::all(array('assigned_to'=>$u['id']));
            if (!$atms && $u['region_id']) $atms = Atm::all(array('region_id'=>$u['region_id']));
            foreach ($atms as $k=>$a) $atms[$k]['reported'] = Report::reportedToday((int)$a['id'],$u['id']);
        }
        ob_start();
        view('petugas.atm_list', array('atms'=>$atms,'fromSchedule'=>!empty($sched),'today'=>$today));
        $c = ob_get_clean();
        view('layouts.app',array('title'=>'ATM Tanggung Jawab','active'=>'atm','content'=>$c,'notifCount'=>0));
    }

    public function history() {
        $u = auth();
        $rows = Report::historyForUser($u['id']);
        ob_start();
        view('petugas.history', array('rows'=>$rows));
        $c = ob_get_clean();
        view('layouts.app',array('title'=>'Histori Pekerjaan','active'=>'history','content'=>$c,'notifCount'=>0));
    }
}
