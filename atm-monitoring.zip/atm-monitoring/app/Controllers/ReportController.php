<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\Atm;
use App\Models\Ref;
use App\Models\Report;
use App\Models\ActivityLog;
use App\Helpers\Watermark;
use App\Helpers\Exporter;

class ReportController extends Controller
{
    private $statusLabel = array(
        'bersih'=>'Bersih','kurang_bersih'=>'Kurang Bersih',
        'kotor'=>'Kotor','tidak_bisa_dibersihkan'=>'Tidak Bisa Dibersihkan',
    );

    public function index() {
        $f = $this->filterInput();
        $this->scopeByRole($f);
        $rows = Report::search($f);
        ob_start();
        view('reports.index', array(
            'rows'=>$rows,'f'=>$f,'statusLabel'=>$this->statusLabel,
            'regions'=>Ref::regions(),'cities'=>Ref::cities(),'petugas'=>Ref::petugas(),
            'atms'=>Atm::all(),
        ));
        $content = ob_get_clean();
        view('layouts.app',array('title'=>'Laporan Kebersihan','active'=>'reports','content'=>$content,'notifCount'=>0));
    }

    public function create() {
        $u = auth();
        $atms = Atm::all(array('assigned_to'=>$u['id']));
        if (!$atms) $atms = Atm::all($u['region_id'] ? array('region_id'=>$u['region_id']) : array());
        ob_start();
        view('petugas.report_form', array('atms'=>$atms,'error'=>flash('error'),'success'=>flash('success')));
        $content = ob_get_clean();
        view('layouts.app',array('title'=>'Buat Laporan Kebersihan','active'=>'report','content'=>$content,'notifCount'=>0));
    }

    public function store() {
        $this->requireCsrf();
        $u = auth();

        $atmId  = (int)$this->input('atm_id');
        $status = $this->input('status');
        $note   = $this->input('note');

        $atm = Atm::find($atmId);
        if (!$atm)      { flash('error','ATM tidak ditemukan.'); redirect('petugas/report'); }
        if ($note==='') { flash('error','Catatan wajib diisi.'); redirect('petugas/report'); }
        if (!isset($this->statusLabel[$status])) { flash('error','Status tidak valid.'); redirect('petugas/report'); }

        $hasBefore = !empty($_FILES['photo_before']['tmp_name']) && is_uploaded_file($_FILES['photo_before']['tmp_name']);
        $hasAfter  = !empty($_FILES['photo_after']['tmp_name'])  && is_uploaded_file($_FILES['photo_after']['tmp_name']);
        if (!$hasBefore || !$hasAfter) {
            flash('error','Foto SEBELUM dan SESUDAH wajib diambil melalui kamera.');
            redirect('petugas/report');
        }

        $lat = $this->input('gps_lat'); $lng = $this->input('gps_lng');
        $acc = $this->input('gps_accuracy');
        $gpsTs = date('Y-m-d H:i:s');

        // Validasi jarak GPS petugas terhadap koordinat ATM
        $distance = null; $flag = 'tanpa_gps';
        if ($lat !== '' && $lng !== '') {
            $distance = \App\Helpers\Geo::distanceMeters($lat, $lng, $atm['latitude'], $atm['longitude']);
            if ($distance === null) {
                $flag = 'tanpa_gps';
            } else {
                $flag = ($distance <= \App\Helpers\Geo::threshold()) ? 'ok' : 'jauh';
            }
        }

        $reportData = array(
            'atm_id'=>$atmId,'user_id'=>$u['id'],'report_date'=>date('Y-m-d'),
            'visit_time'=>date('H:i:s'),'status'=>$status,'note'=>$note,
            'gps_lat'=>$lat,'gps_lng'=>$lng,'gps_accuracy'=>$acc,'gps_timestamp'=>$gpsTs,
            'gps_distance'=>$distance,'location_flag'=>$flag,
        );
        $reportId = Report::create($reportData);

        $wmLines = $this->watermarkLines($u['name'], $atm, $lat, $lng);
        $types = array('before'=>'photo_before','after'=>'photo_after');
        foreach ($types as $type=>$field) {
            $tmp = $_FILES[$field]['tmp_name'];
            $name = $type.'_'.$reportId.'_'.time().'.jpg';
            $dest = UPLOAD_PATH.'/'.$type.'/'.$name;
            $relPath = 'uploads/'.$type.'/'.$name;
            if (Watermark::apply($tmp, $dest, $wmLines)) {
                Report::addPhoto($reportId, $type, $relPath, filesize($dest), implode(' | ',$wmLines));
            } else {
                move_uploaded_file($tmp, $dest);
                Report::addPhoto($reportId, $type, $relPath, @filesize($dest), implode(' | ',$wmLines));
            }
        }

        // Foto TEMUAN (opsional) — mis. kaca/keramik pecah
        if (!empty($_FILES['photo_temuan']['tmp_name']) && is_uploaded_file($_FILES['photo_temuan']['tmp_name'])) {
            $tmpT = $_FILES['photo_temuan']['tmp_name'];
            $catatanTemuan = $this->input('temuan_note');
            $wmT = $wmLines;
            if ($catatanTemuan !== '') $wmT[] = 'TEMUAN: '.$catatanTemuan;
            $nameT = 'temuan_'.$reportId.'_'.time().'.jpg';
            $destT = UPLOAD_PATH.'/findings/'.$nameT;
            $relT  = 'uploads/findings/'.$nameT;
            if (Watermark::apply($tmpT, $destT, $wmT)) {
                Report::addPhoto($reportId, 'temuan', $relT, filesize($destT), implode(' | ',$wmT));
            } else {
                move_uploaded_file($tmpT, $destT);
                Report::addPhoto($reportId, 'temuan', $relT, @filesize($destT), implode(' | ',$wmT));
            }
        }

        ActivityLog::record('create_report','cleaning_reports',$reportId,"Laporan ATM ".$atm['code']);
        flash('success','Laporan kebersihan berhasil dikirim.');
        redirect('petugas/history');
    }

    public function exportExcel() { $this->doExport('xls'); }
    public function exportPdf()   { $this->doExport('pdf'); }

    private function doExport($type) {
        $f = $this->filterInput();
        $this->scopeByRole($f);
        $rows = Report::search($f);
        $headers = array('Tanggal','Jam','Kode ATM','Nama ATM','Petugas','Status','Catatan','Latitude','Longitude','Jarak GPS (m)','Validasi Lokasi');
        $data = array();
        foreach ($rows as $r) {
            $stat = isset($this->statusLabel[$r['status']]) ? $this->statusLabel[$r['status']] : $r['status'];
            $flag = isset($r['location_flag']) ? $r['location_flag'] : '';
            $flagText = $flag==='ok' ? 'Sesuai' : ($flag==='jauh' ? 'Jauh dari ATM' : ($flag==='tanpa_gps' ? 'Tanpa GPS' : '-'));
            $data[] = array(
                tgl_id($r['report_date']), substr($r['visit_time'],0,5),
                $r['atm_code'], $r['atm_name'], $r['petugas_name'], $stat, $r['note'],
                isset($r['gps_lat'])?$r['gps_lat']:'-', isset($r['gps_lng'])?$r['gps_lng']:'-',
                isset($r['gps_distance'])&&$r['gps_distance']!==null?round($r['gps_distance']):'-',
                $flagText,
            );
        }
        if ($type==='xls') Exporter::excel('laporan_kebersihan_'.date('Ymd'), $headers, $data);
        else Exporter::pdf('Laporan Kebersihan ATM', $headers, $data, 'Region IX Kalimantan');
    }

    private function filterInput() {
        return array(
            'date_from'=>isset($_GET['date_from'])?$_GET['date_from']:'',
            'date_to'=>isset($_GET['date_to'])?$_GET['date_to']:'',
            'user_id'=>isset($_GET['user_id'])?$_GET['user_id']:'',
            'atm_id'=>isset($_GET['atm_id'])?$_GET['atm_id']:'',
            'city_id'=>isset($_GET['city_id'])?$_GET['city_id']:'',
            'region_id'=>isset($_GET['region_id'])?$_GET['region_id']:'',
            'status'=>isset($_GET['status'])?$_GET['status']:'',
        );
    }
    private function scopeByRole(&$f) {
        $u = auth();
        if ($u['role']==='petugas') $f['user_id'] = $u['id'];
        elseif ($u['role']==='supervisor' && $u['region_id']) $f['region_id'] = $u['region_id'];
    }
    private function watermarkLines($petugas, $atm, $lat, $lng) {
        return array(
            strtoupper($petugas),
            'ATM '.$atm['code'].' - '.$atm['name'],
            tgl_id(date('Y-m-d')).'  '.date('H:i').' WITA',
            'Lat: '.($lat!==''?$lat:'-').'  Long: '.($lng!==''?$lng:'-'),
        );
    }
}
