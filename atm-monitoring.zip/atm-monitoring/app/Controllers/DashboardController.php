<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Database;

class DashboardController extends Controller
{
    public function index() {
        $role = user_role();
        $stats = $this->summaryStats();

        ob_start();
        view($role . ".dashboard", array('stats' => $stats));
        $content = ob_get_clean();

        view('layouts.app', array(
            'title'      => 'Dashboard',
            'active'     => 'dashboard',
            'content'    => $content,
            'notifCount' => $stats['belum'],
        ));
    }

    private function summaryStats() {
        $u = auth();
        $where = "WHERE a.status='aktif'";
        $params = array();

        if (in_array($u['role'], array('supervisor','petugas'), true) && $u['region_id']) {
            $where .= " AND a.region_id = :rid";
            $params[':rid'] = $u['region_id'];
        }
        if ($u['role'] === 'petugas') {
            $where .= " AND a.assigned_to = :uid";
            $params[':uid'] = $u['id'];
        }

        $totalAtm = (int) Database::scalar("SELECT COUNT(*) FROM atm_locations a $where", $params);
        $sudah = (int) Database::scalar(
            "SELECT COUNT(DISTINCT a.id) FROM atm_locations a
               JOIN cleaning_reports r ON r.atm_id=a.id AND r.report_date=CURDATE()
             $where", $params);
        $belum = max(0, $totalAtm - $sudah);

        $laporanHariIni = (int) Database::scalar(
            "SELECT COUNT(*) FROM cleaning_reports r
               JOIN atm_locations a ON a.id=r.atm_id
             $where AND r.report_date=CURDATE()", $params);

        $petugasAktif = (int) Database::scalar(
            "SELECT COUNT(*) FROM users WHERE role_id=3 AND is_active=1"
            . ($u['region_id'] && $u['role'] !== 'admin' ? " AND region_id=".(int)$u['region_id'] : ''));

        $target = (int) Database::scalar(
            "SELECT COALESCE(MAX(target_count),0) FROM targets WHERE target_date=CURDATE()");
        if ($target === 0) $target = $totalAtm;

        $persen = $target > 0 ? round($sudah / $target * 100) : 0;

        return array('totalAtm'=>$totalAtm,'sudah'=>$sudah,'belum'=>$belum,
                     'laporanHariIni'=>$laporanHariIni,'petugasAktif'=>$petugasAktif,
                     'target'=>$target,'persen'=>$persen);
    }
}
