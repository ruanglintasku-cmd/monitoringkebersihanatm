<?php
namespace App\Controllers\Api;

use App\Core\Controller;
use App\Core\Database;

class MonitoringApiController extends Controller
{
    public function summary() {
        $u = auth();
        $scope = ''; $p = array();
        if ($u['role']!=='admin' && $u['region_id']) { $scope=" AND a.region_id=:r"; $p[':r']=$u['region_id']; }
        $total=(int)Database::scalar("SELECT COUNT(*) FROM atm_locations a WHERE a.status='aktif'".$scope,$p);
        $sudah=(int)Database::scalar(
          "SELECT COUNT(DISTINCT a.id) FROM atm_locations a
             JOIN cleaning_reports r ON r.atm_id=a.id AND r.report_date=CURDATE()
           WHERE a.status='aktif'".$scope,$p);
        $this->json(array('total'=>$total,'sudah'=>$sudah,'belum'=>max(0,$total-$sudah),
            'persen'=>$total?round($sudah/$total*100):0));
    }

    public function mapData() {
        $u = auth();
        $scope=''; $p=array();
        if ($u['role']!=='admin' && $u['region_id']) { $scope=" AND a.region_id=:r"; $p[':r']=$u['region_id']; }
        $rows = Database::all(
          "SELECT a.id,a.code,a.name,a.address,a.latitude,a.longitude,a.city_id,
                  c.name city_name, u.name petugas_name,
                  CASE WHEN cr.id IS NULL THEN 'belum' ELSE 'sudah' END today_status,
                  cr.status clean_status, cr.visit_time,
                  (SELECT file_path FROM report_photos pp
                     JOIN cleaning_reports c2 ON c2.id=pp.report_id
                    WHERE c2.atm_id=a.id ORDER BY pp.id DESC LIMIT 1) last_photo
             FROM atm_locations a
             LEFT JOIN cities c ON c.id=a.city_id
             LEFT JOIN users u ON u.id=a.assigned_to
             LEFT JOIN cleaning_reports cr ON cr.atm_id=a.id AND cr.report_date=CURDATE()
            WHERE a.status='aktif' AND a.latitude IS NOT NULL".$scope,$p);
        foreach ($rows as $k=>$r) if ($r['last_photo']) $rows[$k]['last_photo']=url($r['last_photo']);
        // daftar area untuk dropdown
        $cities = Database::all("SELECT id,name FROM cities ORDER BY name");
        $this->json(array('markers'=>$rows,'cities'=>$cities,'base'=>rtrim(BASE_URL,'/')));
    }

    public function chart() {
        $period = isset($_GET['period']) ? $_GET['period'] : 'week';
        $u = auth();
        $scope = ''; $p = array();
        if ($u['role']!=='admin' && $u['region_id']) { $scope = " AND a.region_id=".(int)$u['region_id']; }

        if ($period === 'year') {
            // 12 bulan terakhir
            $rows = Database::all(
              "SELECT DATE_FORMAT(r.report_date,'%Y-%m') d, COUNT(*) c
                 FROM cleaning_reports r JOIN atm_locations a ON a.id=r.atm_id
                WHERE r.report_date >= DATE_SUB(CURDATE(), INTERVAL 11 MONTH)".$scope."
                GROUP BY d ORDER BY d", $p);
            $label = 'Laporan per Bulan (12 bulan)';
        } elseif ($period === 'month') {
            // 30 hari terakhir
            $rows = Database::all(
              "SELECT r.report_date d, COUNT(*) c
                 FROM cleaning_reports r JOIN atm_locations a ON a.id=r.atm_id
                WHERE r.report_date >= DATE_SUB(CURDATE(), INTERVAL 29 DAY)".$scope."
                GROUP BY r.report_date ORDER BY r.report_date", $p);
            $label = 'Laporan per Hari (30 hari)';
        } else {
            // minggu: 7 hari terakhir
            $rows = Database::all(
              "SELECT r.report_date d, COUNT(*) c
                 FROM cleaning_reports r JOIN atm_locations a ON a.id=r.atm_id
                WHERE r.report_date >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)".$scope."
                GROUP BY r.report_date ORDER BY r.report_date", $p);
            $label = 'Laporan per Hari (7 hari)';
        }
        $this->json(array('rows'=>$rows,'label'=>$label,'period'=>$period));
    }

    /** Grafik per area (untuk dashboard admin) */
    public function chartArea() {
        $rows = Database::all(
          "SELECT c.name area,
                  COUNT(DISTINCT a.id) total,
                  COUNT(DISTINCT CASE WHEN cr.id IS NOT NULL THEN a.id END) sudah
             FROM atm_locations a
             LEFT JOIN cities c ON c.id=a.city_id
             LEFT JOIN cleaning_reports cr ON cr.atm_id=a.id AND cr.report_date=CURDATE()
            WHERE a.status='aktif'
            GROUP BY c.id, c.name ORDER BY c.name");
        $this->json(array('rows'=>$rows));
    }
}
